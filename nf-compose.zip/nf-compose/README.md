# Nova Fusion — docker-compose test stack

For **testing before deploy** only. Read "Why not compose for production" at the bottom
before you decide to skip the PM2/nginx-native setup entirely.

## Stack

- `db` — Postgres 16, port 5433 on host (avoids clashing with any native Postgres on 5432)
- `migrate` — one-shot container, runs `node db/migrate.js up` then exits
- `api` — the backend (phase 2 + phase 4 merged), port 3000
- `web` — nginx serving `portal.html` and reverse-proxying `/api` to `api`, port 8080

## Prerequisites on the Ubuntu server

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-v2
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
newgrp docker   # or log out/in — applies the group without a fresh shell
```

## 1. Get the stack onto the server

```bash
scp -r nf-compose/ user@your-server-ip:/home/user/
ssh user@your-server-ip
cd nf-compose
```

## 2. Configure secrets

```bash
cp .env.example .env
nano .env
```

Generate the two JWT secrets (must be different values):

```bash
openssl rand -base64 48
openssl rand -base64 48
```

Paste one into `JWT_ACCESS_SECRET`, the other into `JWT_REFRESH_SECRET`, and set
`POSTGRES_PASSWORD` to anything reasonably strong — this is a test password, it never
leaves this compose network.

## 3. Build and start

```bash
docker compose up -d --build
```

This builds the `api` image, starts Postgres, waits for its healthcheck, runs migrations
(`migrate` service, exits on success), then starts `api` and `web`.

Watch it come up:

```bash
docker compose ps
docker compose logs -f migrate    # confirm migrations succeeded, then Ctrl+C
docker compose logs -f api        # confirm "listening on port 3000"
```

## 4. Create the admin user

```bash
docker compose run --rm \
  -e ADMIN_NAME="Founder" \
  -e ADMIN_EMAIL="you@novafusion.in" \
  -e ADMIN_PASSWORD="ChangeThisPassword123" \
  api node scripts/create-admin.js
```

## 5. Verify

```bash
curl http://localhost:8080/api/health
```

Then in a browser: `http://your-server-ip:8080/` → login screen → sign in with the admin
credentials from step 4.

If the server has a firewall (`ufw`), open the test port temporarily:

```bash
sudo ufw allow 8080/tcp
```

## Day-to-day testing commands

```bash
docker compose logs -f api          # tail backend logs
docker compose restart api          # after you edit backend source
docker compose exec db psql -U novafusion -d novafusion   # poke the DB directly
docker compose down                 # stop everything, keep data (named volumes persist)
docker compose down -v              # stop and WIPE data — full reset for a clean test run
```

Rebuilding after a backend code change:

```bash
docker compose up -d --build api
```

## Why not compose for production

Direct recommendation, not a hedge: **use this for testing, use PM2 + native Postgres +
nginx for the actual production deploy**, for three concrete reasons —

1. **Single-container Postgres has no backup/replication story.** `docker compose down -v`
   destroys client project data and shoot footage metadata in one command. That's a feature
   for testing (fast reset) and a liability in production (one bad command wipes the business).
2. **Upload volume durability.** `uploads_data` is a Docker named volume on local disk —
   same single-point-of-failure as the native `UPLOAD_DIR` approach, but now with an extra
   abstraction layer between you and the actual files when something goes wrong at 2am.
3. **No operational upside for your scale.** Compose's value is reproducible multi-service
   orchestration across environments or nodes. You have one server. PM2's `pm2 reload` gives
   you zero-downtime restarts and `pm2 logs`/`pm2 monit` without a container runtime between
   you and the process — less surface area to debug when something breaks.

If you later add more app servers, move to managed Postgres, or want CI to spin up ephemeral
environments per PR — that's when compose (or better, a real orchestrator) earns its keep.
Right now it would be solving a problem you don't have yet.
