// scripts/create-admin.js
// Bootstrap the first admin. Run interactively or with env vars.
//
// Usage:
//   ADMIN_NAME="Owner" ADMIN_EMAIL="you@example.com" ADMIN_PASSWORD="..." node scripts/create-admin.js
//
// Refuses to run if any user already exists — use the API after that.

require('dotenv').config();
const readline = require('readline');
const bcrypt = require('bcryptjs');
const { query, close } = require('../src/db/pool');
const env = require('../src/config/env');

function ask(prompt, hidden = false) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    if (hidden) {
      // Suppress echo for password
      const stdin = process.stdin;
      stdin.on('data', (char) => {
        const c = char + '';
        if (c === '\n' || c === '\r' || c === '\u0004') stdin.pause();
        else process.stdout.write('\b*');
      });
    }
    rl.question(prompt, (answer) => { rl.close(); resolve(answer.trim()); });
  });
}

async function main() {
  const { rows } = await query('SELECT count(*)::int AS n FROM users');
  if (rows[0].n > 0) {
    console.error('❌ Users already exist. Use the API (admin endpoint) to create more.');
    process.exit(1);
  }

  const name     = process.env.ADMIN_NAME     || await ask('Admin name: ');
  const email    = process.env.ADMIN_EMAIL    || await ask('Admin email: ');
  const password = process.env.ADMIN_PASSWORD || await ask('Admin password (min 8 chars): ');

  if (!name || !email || !password) {
    console.error('❌ All fields required'); process.exit(1);
  }
  if (password.length < 8) {
    console.error('❌ Password must be at least 8 characters'); process.exit(1);
  }

  const password_hash = await bcrypt.hash(password, env.BCRYPT_ROUNDS);
  await query(
    `INSERT INTO users (name, email, password_hash, role)
     VALUES ($1, $2, $3, 'Admin')`,
    [name, email.toLowerCase(), password_hash]
  );

  console.log(`✓ Admin user created: ${email}`);
  console.log('  You can now log in at POST /api/auth/login');
}

main()
  .catch((err) => { console.error(err.message); process.exit(1); })
  .finally(() => close());
