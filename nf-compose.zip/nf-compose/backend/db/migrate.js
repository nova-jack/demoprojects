// db/migrate.js
// Simple SQL-file migration runner. Tracks applied migrations in a `_migrations` table.
// Phase 1 stub: creates the tracking table only. Phase 2 will add real migration files.
//
// Usage:
//   npm run migrate          # apply pending migrations
//   npm run migrate:status   # list applied + pending
//   npm run migrate:down     # roll back last migration

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const env = require('../src/config/env');

const pool = new Pool(
  env.DATABASE_URL ? { connectionString: env.DATABASE_URL } : {
    host: env.PGHOST, port: env.PGPORT, database: env.PGDATABASE, user: env.PGUSER, password: env.PGPASSWORD,
  }
);

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');

async function ensureMigrationsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS _migrations (
      id SERIAL PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}

function listMigrationFiles() {
  if (!fs.existsSync(MIGRATIONS_DIR)) return [];
  return fs.readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith('.up.sql'))
    .sort();
}

async function getApplied() {
  const r = await pool.query('SELECT name FROM _migrations ORDER BY id');
  return new Set(r.rows.map((row) => row.name));
}

async function up() {
  await ensureMigrationsTable();
  const files = listMigrationFiles();
  const applied = await getApplied();
  const pending = files.filter((f) => !applied.has(f));

  if (pending.length === 0) {
    console.log('✓ No pending migrations');
    return;
  }

  for (const file of pending) {
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
    console.log(`→ Applying ${file}`);
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query('INSERT INTO _migrations (name) VALUES ($1)', [file]);
      await client.query('COMMIT');
      console.log(`  ✓ ${file}`);
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(`  ✗ ${file} failed:`, err.message);
      process.exit(1);
    } finally {
      client.release();
    }
  }
}

async function down() {
  await ensureMigrationsTable();
  const r = await pool.query('SELECT name FROM _migrations ORDER BY id DESC LIMIT 1');
  if (r.rows.length === 0) {
    console.log('No migrations to roll back');
    return;
  }
  const name = r.rows[0].name;
  const downFile = name.replace('.up.sql', '.down.sql');
  const downPath = path.join(MIGRATIONS_DIR, downFile);
  if (!fs.existsSync(downPath)) {
    console.error(`Down migration missing: ${downFile}`);
    process.exit(1);
  }
  const sql = fs.readFileSync(downPath, 'utf8');
  console.log(`← Rolling back ${name}`);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(sql);
    await client.query('DELETE FROM _migrations WHERE name = $1', [name]);
    await client.query('COMMIT');
    console.log(`  ✓ Rolled back ${name}`);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Rollback failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
  }
}

async function status() {
  await ensureMigrationsTable();
  const files = listMigrationFiles();
  const applied = await getApplied();
  console.log('Migration status:');
  if (files.length === 0) {
    console.log('  (no migration files found in db/migrations)');
  }
  for (const f of files) {
    console.log(`  ${applied.has(f) ? '✓' : '·'} ${f}`);
  }
}

const cmd = process.argv[2] || 'up';
const handlers = { up, down, status };
const handler = handlers[cmd];
if (!handler) {
  console.error(`Unknown command: ${cmd}. Use: up | down | status`);
  process.exit(1);
}

handler()
  .then(() => pool.end())
  .catch((err) => {
    console.error(err);
    pool.end();
    process.exit(1);
  });
