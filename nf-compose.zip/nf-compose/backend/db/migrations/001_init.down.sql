-- 001_init.down.sql — roll back the initial schema
DROP VIEW  IF EXISTS v_projects;
DROP VIEW  IF EXISTS v_invoices;
DROP TABLE IF EXISTS app_settings;
DROP TABLE IF EXISTS refresh_tokens;
DROP TABLE IF EXISTS expenses;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS invoice_items;
DROP TABLE IF EXISTS invoices;
DROP SEQUENCE IF EXISTS invoice_number_seq;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS users;
DROP TYPE  IF EXISTS payment_state;
DROP TYPE  IF EXISTS priority_lvl;
DROP TYPE  IF EXISTS user_role;
DROP FUNCTION IF EXISTS set_updated_at();
-- Don't drop citext — other things may use it
