-- 001_init.up.sql
-- Initial schema for Nova Fusion RCM Portal.
-- The migration runner wraps this whole file in a transaction, so it's all-or-nothing.

CREATE EXTENSION IF NOT EXISTS citext;  -- case-insensitive text for emails

-- ── Helper trigger function: auto-update updated_at on UPDATE ──
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ── Enums ──────────────────────────────────────────────────
CREATE TYPE user_role     AS ENUM ('Admin', 'Manager', 'Editor', 'Staff');
CREATE TYPE priority_lvl  AS ENUM ('High', 'Medium', 'Low');
CREATE TYPE payment_state AS ENUM ('Paid', 'Unpaid', 'Partial');

-- ── Users ──────────────────────────────────────────────────
CREATE TABLE users (
  id             BIGSERIAL PRIMARY KEY,
  name           TEXT NOT NULL,
  email          CITEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,
  phone          TEXT,
  role           user_role NOT NULL DEFAULT 'Staff',
  dept           TEXT,
  color          TEXT NOT NULL DEFAULT '#3b82f6',
  is_active      BOOLEAN NOT NULL DEFAULT true,
  last_login_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Clients ────────────────────────────────────────────────
CREATE TABLE clients (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  company     TEXT,
  phone       TEXT,
  email       CITEXT,
  gst         TEXT,
  city        TEXT,
  address     TEXT,
  notes       TEXT,
  color       TEXT NOT NULL DEFAULT '#3b82f6',
  deleted_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER clients_updated_at BEFORE UPDATE ON clients
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
-- Partial indexes only cover non-deleted rows = smaller, faster
CREATE INDEX clients_active_idx ON clients (id)    WHERE deleted_at IS NULL;
CREATE INDEX clients_email_idx  ON clients (email) WHERE deleted_at IS NULL;

-- ── Projects ───────────────────────────────────────────────
-- amount = total quoted; paid_amount tracks what we've collected.
-- payment status (Paid/Partial/Unpaid) is derived in v_projects view.
CREATE TABLE projects (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  client_id     BIGINT NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
  type          TEXT,
  amount        NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (amount >= 0),
  paid_amount   NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
  stage         SMALLINT NOT NULL DEFAULT 1 CHECK (stage BETWEEN 1 AND 9),
  priority      priority_lvl NOT NULL DEFAULT 'Medium',
  assignee_id   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  start_date    DATE,
  deadline      DATE,
  description   TEXT,
  deleted_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (paid_amount <= amount)
);
CREATE TRIGGER projects_updated_at BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX projects_client_idx   ON projects(client_id)   WHERE deleted_at IS NULL;
CREATE INDEX projects_assignee_idx ON projects(assignee_id) WHERE deleted_at IS NULL;
CREATE INDEX projects_deadline_idx ON projects(deadline)    WHERE deleted_at IS NULL;
CREATE INDEX projects_stage_idx    ON projects(stage)       WHERE deleted_at IS NULL;

-- ── Invoices ───────────────────────────────────────────────
-- ID is human-readable like INV-1001 (matches your frontend's expectation).
CREATE SEQUENCE invoice_number_seq START 1001;

CREATE TABLE invoices (
  id              TEXT PRIMARY KEY,
  client_id       BIGINT NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
  invoice_date    DATE NOT NULL,
  due_date        DATE NOT NULL,
  subtotal        NUMERIC(14,2) NOT NULL CHECK (subtotal >= 0),
  gst_rate        NUMERIC(5,2)  NOT NULL DEFAULT 18.00 CHECK (gst_rate BETWEEN 0 AND 100),
  gst_amount      NUMERIC(14,2) NOT NULL CHECK (gst_amount >= 0),
  total           NUMERIC(14,2) NOT NULL CHECK (total >= 0),
  paid_amount     NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (paid_amount <= total),
  CHECK (due_date >= invoice_date)
);
CREATE TRIGGER invoices_updated_at BEFORE UPDATE ON invoices
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX invoices_client_idx ON invoices(client_id);
CREATE INDEX invoices_due_idx    ON invoices(due_date);
CREATE INDEX invoices_date_idx   ON invoices(invoice_date);

-- ── Invoice line items ─────────────────────────────────────
-- Each invoice has 1+ items. Items can optionally link to a project.
CREATE TABLE invoice_items (
  id           BIGSERIAL PRIMARY KEY,
  invoice_id   TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  project_id   BIGINT REFERENCES projects(id) ON DELETE SET NULL,
  description  TEXT NOT NULL,
  amount       NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  position     SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX invoice_items_invoice_idx ON invoice_items(invoice_id);
CREATE INDEX invoice_items_project_idx ON invoice_items(project_id);

-- ── Tasks ──────────────────────────────────────────────────
CREATE TABLE tasks (
  id          BIGSERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  project_id  BIGINT REFERENCES projects(id) ON DELETE CASCADE,
  assignee_id BIGINT REFERENCES users(id)    ON DELETE SET NULL,
  due_date    DATE,
  priority    priority_lvl NOT NULL DEFAULT 'Medium',
  done        BOOLEAN NOT NULL DEFAULT false,
  done_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX tasks_assignee_idx ON tasks(assignee_id);
CREATE INDEX tasks_project_idx  ON tasks(project_id);
CREATE INDEX tasks_open_due_idx ON tasks(due_date) WHERE done = false;

-- ── Expenses ───────────────────────────────────────────────
CREATE TABLE expenses (
  id            BIGSERIAL PRIMARY KEY,
  category      TEXT NOT NULL,
  amount        NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  icon          TEXT,
  expense_date  DATE NOT NULL DEFAULT CURRENT_DATE,
  notes         TEXT,
  created_by    BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX expenses_date_idx ON expenses(expense_date);
CREATE INDEX expenses_cat_idx  ON expenses(category);

-- ── Refresh tokens ─────────────────────────────────────────
-- Server-side storage so logout/revoke actually works.
-- We store only a SHA-256 hash of the token, never the token itself.
CREATE TABLE refresh_tokens (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,
  expires_at   TIMESTAMPTZ NOT NULL,
  revoked_at   TIMESTAMPTZ,
  user_agent   TEXT,
  ip           TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX refresh_tokens_user_idx   ON refresh_tokens(user_id);
CREATE INDEX refresh_tokens_active_idx ON refresh_tokens(user_id) WHERE revoked_at IS NULL;

-- ── App settings (company profile, invoice settings, etc) ─
CREATE TABLE app_settings (
  key         TEXT PRIMARY KEY,
  value       JSONB NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER app_settings_updated_at BEFORE UPDATE ON app_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Views: derive payment status from the numbers ──────────
-- Single source of truth: paid_amount vs total. Status is always consistent.
CREATE VIEW v_invoices AS
SELECT
  i.*,
  CASE
    WHEN i.paid_amount >= i.total THEN 'Paid'::payment_state
    WHEN i.paid_amount = 0        THEN 'Unpaid'::payment_state
    ELSE 'Partial'::payment_state
  END AS status,
  (i.total - i.paid_amount) AS outstanding
FROM invoices i;

CREATE VIEW v_projects AS
SELECT
  p.*,
  CASE
    WHEN p.paid_amount >= p.amount THEN 'Paid'::payment_state
    WHEN p.paid_amount = 0         THEN 'Unpaid'::payment_state
    ELSE 'Partial'::payment_state
  END AS payment
FROM projects p
WHERE p.deleted_at IS NULL;
