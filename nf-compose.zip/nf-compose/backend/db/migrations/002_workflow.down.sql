-- 002_workflow.down.sql — roll back phase 4
ALTER TABLE expenses DROP COLUMN IF EXISTS project_id, DROP COLUMN IF EXISTS user_id, DROP COLUMN IF EXISTS expense_type;
DROP TABLE IF EXISTS attachments;
DROP TABLE IF EXISTS activity_log;
DROP TABLE IF EXISTS project_members;
DROP TABLE IF EXISTS checklist_items;
DROP TABLE IF EXISTS workflow_steps;
DROP TYPE  IF EXISTS expense_type;
DROP TYPE  IF EXISTS step_status;
DELETE FROM app_settings WHERE key = 'workflow_template';
