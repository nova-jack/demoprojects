-- 002_workflow.up.sql
-- Phase 4: project workflow pipeline, per-step checklists, project members,
-- activity timeline, file attachments, and expense classification
-- (company bills / staff payments / project expenses) for the founder's finance view.

-- ── Enums ──────────────────────────────────────────────────
CREATE TYPE step_status  AS ENUM ('pending', 'active', 'done');
CREATE TYPE expense_type AS ENUM ('company_bill', 'staff_payment', 'project_expense', 'other');

-- ── Workflow steps ─────────────────────────────────────────
-- Ordered pipeline per project: Requirement → Graphics → Shoot → Gather Data
-- → Edit → Review → Changes → Final Submit (template is editable per project).
CREATE TABLE workflow_steps (
  id          BIGSERIAL PRIMARY KEY,
  project_id  BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  position    SMALLINT NOT NULL,
  name        TEXT NOT NULL,
  status      step_status NOT NULL DEFAULT 'pending',
  assignee_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  due_date    DATE,
  notes       TEXT,
  started_at  TIMESTAMPTZ,
  done_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (project_id, position)
);
CREATE TRIGGER workflow_steps_updated_at BEFORE UPDATE ON workflow_steps
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX workflow_steps_project_idx  ON workflow_steps(project_id);
CREATE INDEX workflow_steps_assignee_idx ON workflow_steps(assignee_id) WHERE status <> 'done';

-- ── Checklist items (inside a step) ────────────────────────
CREATE TABLE checklist_items (
  id          BIGSERIAL PRIMARY KEY,
  step_id     BIGINT NOT NULL REFERENCES workflow_steps(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  assignee_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  done        BOOLEAN NOT NULL DEFAULT false,
  done_at     TIMESTAMPTZ,
  done_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
  position    SMALLINT NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX checklist_items_step_idx     ON checklist_items(step_id);
CREATE INDEX checklist_items_assignee_idx ON checklist_items(assignee_id) WHERE done = false;

-- ── Project members (visibility + team) ────────────────────
-- A Staff/Editor user can see a project if they are the project assignee,
-- a member here, or assigned to any step/checklist item in it.
CREATE TABLE project_members (
  project_id BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id    BIGINT NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  role_note  TEXT,
  added_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (project_id, user_id)
);
CREATE INDEX project_members_user_idx ON project_members(user_id);

-- ── Activity log (project timeline + comments) ─────────────
CREATE TABLE activity_log (
  id         BIGSERIAL PRIMARY KEY,
  project_id BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,       -- created | step_started | step_done | checklist_done | comment | file_added | member_added | ...
  detail     TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX activity_log_project_idx ON activity_log(project_id, created_at DESC);

-- ── Attachments (images / videos / receipts) ───────────────
-- Binary lives on disk (UPLOAD_DIR); only metadata lives here.
CREATE TABLE attachments (
  id            BIGSERIAL PRIMARY KEY,
  entity_type   TEXT NOT NULL CHECK (entity_type IN ('project', 'expense')),
  entity_id     BIGINT NOT NULL,
  stored_name   TEXT NOT NULL UNIQUE,   -- random name on disk
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size_bytes    BIGINT NOT NULL,
  uploaded_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX attachments_entity_idx ON attachments(entity_type, entity_id);

-- ── Expense classification for the finance view ────────────
ALTER TABLE expenses
  ADD COLUMN expense_type expense_type NOT NULL DEFAULT 'other',
  ADD COLUMN user_id    BIGINT REFERENCES users(id)    ON DELETE SET NULL,  -- who got paid (staff_payment)
  ADD COLUMN project_id BIGINT REFERENCES projects(id) ON DELETE SET NULL;  -- cost attribution
CREATE INDEX expenses_type_idx ON expenses(expense_type);
CREATE INDEX expenses_user_idx ON expenses(user_id) WHERE user_id IS NOT NULL;

-- ── Default workflow template (editable in app_settings) ───
INSERT INTO app_settings (key, value) VALUES (
  'workflow_template',
  '["Requirement","Graphics","Shoot","Gather Data","Edit","Review","Changes","Final Submit"]'::jsonb
) ON CONFLICT (key) DO NOTHING;
