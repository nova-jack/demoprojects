// src/config/logger.js
const pino = require('pino');
const env = require('./env');

const logger = pino({
  level: env.LOG_LEVEL,
  // Pretty-print in dev, structured JSON in prod for log aggregators
  transport: env.isDev
    ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'HH:MM:ss', ignore: 'pid,hostname' } }
    : undefined,
  // Never log secrets, even by accident
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'req.body.password',
      'req.body.currentPassword',
      'req.body.newPassword',
      '*.password',
      '*.password_hash',
      '*.token',
    ],
    censor: '[REDACTED]',
  },
});

module.exports = logger;
