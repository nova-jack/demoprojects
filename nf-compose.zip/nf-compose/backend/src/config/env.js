// src/config/env.js
// Validates env on boot. If anything is missing or wrong, the process exits
// with a clear message — better to fail loudly at startup than silently in prod.

require('dotenv').config();
const { z } = require('zod');

const schema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),

  DATABASE_URL: z.string().regex(/^postgres(?:ql)?:\/\//, 'DATABASE_URL must start with postgres:// or postgresql://').optional(),
  PGHOST: z.string().optional(),
  PGPORT: z.coerce.number().int().positive().optional(),
  PGDATABASE: z.string().optional(),
  PGUSER: z.string().optional(),
  PGPASSWORD: z.string().optional(),

  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET must be at least 32 chars'),
  JWT_REFRESH_SECRET: z.string().min(32, 'JWT_REFRESH_SECRET must be at least 32 chars'),
  JWT_ACCESS_TTL: z.string().default('15m'),
  JWT_REFRESH_TTL: z.string().default('7d'),
  BCRYPT_ROUNDS: z.coerce.number().int().min(10).max(15).default(12),

  CORS_ORIGINS: z.string().default('http://localhost:5173'),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(15 * 60 * 1000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(300),
  AUTH_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(10),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('❌ Invalid environment configuration:');
  for (const issue of parsed.error.issues) {
    console.error(`  • ${issue.path.join('.')}: ${issue.message}`);
  }
  process.exit(1);
}

const env = parsed.data;

// Either DATABASE_URL or all PG* fields must be present
if (!env.DATABASE_URL && !(env.PGHOST && env.PGDATABASE && env.PGUSER)) {
  console.error('❌ Database config missing: provide DATABASE_URL or PGHOST + PGDATABASE + PGUSER');
  process.exit(1);
}

// Refuse to boot in prod with insecure secrets
if (env.NODE_ENV === 'production') {
  if (env.JWT_ACCESS_SECRET.includes('CHANGE_ME') || env.JWT_REFRESH_SECRET.includes('CHANGE_ME')) {
    console.error('❌ Production refuses to start with placeholder JWT secrets. Generate real ones with: openssl rand -hex 64');
    process.exit(1);
  }
  if (env.JWT_ACCESS_SECRET === env.JWT_REFRESH_SECRET) {
    console.error('❌ JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must differ.');
    process.exit(1);
  }
}

env.corsOrigins = env.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean);
env.isProd = env.NODE_ENV === 'production';
env.isDev = env.NODE_ENV === 'development';

module.exports = env;
