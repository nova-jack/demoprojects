// src/app.js
// Builds the Express app. Order of middleware matters — security & parsing first,
// then logging, then routes, then error handlers (always last).

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const pinoHttp = require('pino-http');
const crypto = require('crypto');

const env = require('./config/env');
const logger = require('./config/logger');
const apiRouter = require('./routes');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();

// Trust the first proxy (nginx/cloudflare) so req.ip is correct
app.set('trust proxy', 1);
app.disable('x-powered-by');

// ── Security headers ────────────────────────────────────────
app.use(helmet());

// ── CORS ────────────────────────────────────────────────────
app.use(
  cors({
    origin: (origin, cb) => {
      // No origin = same-origin / curl / health checks. Allow.
      if (!origin) return cb(null, true);
      if (env.corsOrigins.includes('*') || env.corsOrigins.includes(origin)) {
        return cb(null, true);
      }
      cb(new Error(`CORS: origin ${origin} not allowed`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  })
);

// ── Body parsing ────────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ── Request ID + structured request logging ────────────────
app.use((req, res, next) => {
  req.id = req.headers['x-request-id'] || crypto.randomUUID();
  res.setHeader('x-request-id', req.id);
  next();
});

app.use(
  pinoHttp({
    logger,
    genReqId: (req) => req.id,
    customLogLevel: (req, res, err) => {
      if (err || res.statusCode >= 500) return 'error';
      if (res.statusCode >= 400) return 'warn';
      return 'info';
    },
    // Skip noisy health checks
    autoLogging: { ignore: (req) => req.url.startsWith('/api/health') },
  })
);

// ── Global rate limit ──────────────────────────────────────
app.use(
  rateLimit({
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    max: env.RATE_LIMIT_MAX,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: { code: 'RATE_LIMITED', message: 'Too many requests' } },
  })
);

// ── Routes ─────────────────────────────────────────────────
app.use('/api', apiRouter);

// ── 404 + error handlers (must be last) ────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
