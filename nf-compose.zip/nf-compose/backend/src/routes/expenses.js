// src/routes/expenses.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/expensesService');
const { idParam } = require('../validators/common');
const { expenseCreateSchema, expenseUpdateSchema, expenseListQuery } = require('../validators/expenses');

const router = express.Router();
router.use(requireAuth);

router.get('/',
  validate({ query: expenseListQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.post('/',
  requireRole('Admin', 'Manager'),
  validate({ body: expenseCreateSchema }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.create(req.body, req.user.id)))
);

router.patch('/:id',
  requireRole('Admin', 'Manager'),
  validate({ params: idParam, body: expenseUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body)))
);

router.delete('/:id',
  requireRole('Admin'),
  validate({ params: idParam }),
  asyncHandler(async (req, res) => { await svc.remove(req.params.id); res.status(204).end(); })
);

module.exports = router;
