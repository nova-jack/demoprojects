// src/routes/index.js — Phase 4: adds workflow, files, finance
const express = require('express');

const healthRouter    = require('./health');
const authRouter      = require('./auth');
const clientsRouter   = require('./clients');
const projectsRouter  = require('./projects');
const invoicesRouter  = require('./invoices');
const tasksRouter     = require('./tasks');
const expensesRouter  = require('./expenses');
const usersRouter     = require('./users');
const dashboardRouter = require('./dashboard');
const workflowRouter  = require('./workflow');
const filesRouter     = require('./files');
const financeRouter   = require('./finance');

const router = express.Router();

router.use('/health',    healthRouter);
router.use('/auth',      authRouter);
router.use('/clients',   clientsRouter);
router.use('/projects',  projectsRouter);   // legacy — old portal
router.use('/invoices',  invoicesRouter);
router.use('/tasks',     tasksRouter);
router.use('/expenses',  expensesRouter);   // legacy — old portal
router.use('/users',     usersRouter);
router.use('/dashboard', dashboardRouter);
router.use('/workflow',  workflowRouter);   // phase 4
router.use('/files',     filesRouter);      // phase 4
router.use('/finance',   financeRouter);    // phase 4 (Admin only)

router.get('/', (req, res) => {
  res.json({ name: 'Nova Fusion API', version: '2.0.0', status: 'ok' });
});

module.exports = router;
