// src/routes/health.js
const express = require('express');
const { query } = require('../db/pool');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

// Liveness: process is up. Used by load balancers / k8s.
router.get('/live', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// Readiness: process is up AND db is reachable.
router.get('/ready', asyncHandler(async (req, res) => {
  await query('SELECT 1');
  res.json({ status: 'ok', db: 'ok' });
}));

module.exports = router;
