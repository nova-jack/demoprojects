// src/routes/files.js
// Upload + serve attachments. Videos/images stream from disk with byte-range
// support (res.sendFile handles Range headers → video scrubbing works).
//
// Auth for media tags: <img>/<video> can't send an Authorization header, so
// GET also accepts ?t=<accessToken>. Trade-off: the token can land in access
// logs for those requests. Acceptable for an internal team tool; if that ever
// bothers you, switch to short-lived signed file URLs.

const express = require('express');
const multer = require('multer');
const { requireAuth } = require('../middleware/auth');
const { verifyAccessToken } = require('../utils/jwt');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/filesService');

const router = express.Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, svc.UPLOAD_DIR),
    filename: (req, file, cb) => cb(null, svc.storedNameFor(file.originalname)),
  }),
  limits: { fileSize: svc.MAX_BYTES },
  fileFilter: (req, file, cb) => {
    if (svc.ALLOWED_MIME.has(file.mimetype)) return cb(null, true);
    cb(new Error(`File type ${file.mimetype} not allowed`));
  },
});

// Accept Bearer header OR ?t= token (for <img>/<video> src)
function authFlexible(req, res, next) {
  if (req.headers.authorization) return requireAuth(req, res, next);
  const t = req.query.t;
  if (!t) return next(AppError.unauthorized('Missing token'));
  try {
    const payload = verifyAccessToken(t);
    req.user = { id: payload.sub, role: payload.role, email: payload.email };
    next();
  } catch {
    next(AppError.unauthorized('Invalid token'));
  }
}

// POST /api/files/:entityType/:entityId  (multipart field: "file")
router.post('/:entityType/:entityId',
  requireAuth,
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!req.file) throw AppError.badRequest('No file received (field name must be "file")');
    try {
      const rec = await svc.saveRecord(req.user, {
        entityType: req.params.entityType,
        entityId: Number(req.params.entityId),
        storedName: req.file.filename,
        originalName: req.file.originalname,
        mime: req.file.mimetype,
        size: req.file.size,
      });
      res.status(201).json(rec);
    } catch (err) {
      // multer already wrote the file; don't leave orphans on rejection
      require('fs').promises.unlink(req.file.path).catch(() => {});
      throw err;
    }
  })
);

// GET /api/files/:id  → streams the binary (Range supported)
router.get('/:id',
  authFlexible,
  asyncHandler(async (req, res) => {
    const { meta, absPath } = await svc.getForRead(req.user, Number(req.params.id));
    res.setHeader('Content-Type', meta.mime);
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(meta.original_name)}"`);
    res.sendFile(absPath);
  })
);

router.delete('/:id',
  requireAuth,
  asyncHandler(async (req, res) => res.json(await svc.remove(req.user, Number(req.params.id))))
);

module.exports = router;
