// src/routes/auth.js
const express = require('express');
const rateLimit = require('express-rate-limit');

const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const env = require('../config/env');
const authService = require('../services/authService');
const {
  loginSchema, registerSchema, refreshSchema, changePasswordSchema,
} = require('../validators/auth');

const router = express.Router();

// Stricter rate limit for auth endpoints — slow down brute-force.
const authLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.AUTH_RATE_LIMIT_MAX,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: { code: 'RATE_LIMITED', message: 'Too many auth attempts, try again later' } },
});

// POST /api/auth/login
router.post(
  '/login',
  authLimiter,
  validate({ body: loginSchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.login({
      email: req.body.email,
      password: req.body.password,
      userAgent: req.headers['user-agent'],
      ip: req.ip,
    });
    res.json(result);
  })
);

// POST /api/auth/register — Admin-only (no public signup for an internal portal)
router.post(
  '/register',
  requireAuth,
  requireRole('Admin'),
  validate({ body: registerSchema }),
  asyncHandler(async (req, res) => {
    const user = await authService.register(req.body);
    res.status(201).json({ user });
  })
);

// POST /api/auth/refresh
router.post(
  '/refresh',
  authLimiter,
  validate({ body: refreshSchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.refresh(
      req.body.refreshToken,
      req.headers['user-agent'],
      req.ip
    );
    res.json(result);
  })
);

// POST /api/auth/logout
router.post(
  '/logout',
  requireAuth,
  asyncHandler(async (req, res) => {
    await authService.logout(req.body?.refreshToken);
    res.json({ ok: true });
  })
);

// POST /api/auth/logout-all — revoke every session for the current user
router.post(
  '/logout-all',
  requireAuth,
  asyncHandler(async (req, res) => {
    await authService.logoutAll(req.user.id);
    res.json({ ok: true });
  })
);

// GET /api/auth/me
router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await authService.getMe(req.user.id);
    res.json({ user });
  })
);

// POST /api/auth/change-password
router.post(
  '/change-password',
  requireAuth,
  validate({ body: changePasswordSchema }),
  asyncHandler(async (req, res) => {
    await authService.changePassword(req.user.id, req.body);
    res.json({ ok: true });
  })
);

module.exports = router;
