// src/routes/projects.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/projectsService');
const { idParam } = require('../validators/common');
const { projectCreateSchema, projectUpdateSchema, projectListQuery } = require('../validators/projects');

const router = express.Router();
router.use(requireAuth);

router.get('/',
  validate({ query: projectListQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.get('/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.getById(req.params.id)))
);

router.post('/',
  requireRole('Admin', 'Manager'),
  validate({ body: projectCreateSchema }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.create(req.body)))
);

router.patch('/:id',
  requireRole('Admin', 'Manager', 'Editor'),
  validate({ params: idParam, body: projectUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body)))
);

router.delete('/:id',
  requireRole('Admin'),
  validate({ params: idParam }),
  asyncHandler(async (req, res) => { await svc.softDelete(req.params.id); res.status(204).end(); })
);

module.exports = router;
