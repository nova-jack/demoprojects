// src/routes/tasks.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/tasksService');
const { idParam } = require('../validators/common');
const { taskCreateSchema, taskUpdateSchema, taskListQuery } = require('../validators/tasks');

const router = express.Router();
router.use(requireAuth);

router.get('/',
  validate({ query: taskListQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.post('/',
  validate({ body: taskCreateSchema }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.create(req.body)))
);

router.patch('/:id',
  validate({ params: idParam, body: taskUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body)))
);

router.delete('/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => { await svc.remove(req.params.id); res.status(204).end(); })
);

module.exports = router;
