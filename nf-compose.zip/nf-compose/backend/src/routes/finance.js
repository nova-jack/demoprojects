// src/routes/finance.js — founder-only money view
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/financeService');
const { idParam } = require('../validators/common');
const { expenseCreate } = require('../validators/workflow');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

router.get('/summary', asyncHandler(async (req, res) => res.json(await svc.summary())));

router.post('/expenses',
  validate({ body: expenseCreate }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.addExpense(req.user, req.body))));

router.delete('/expenses/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.deleteExpense(req.params.id))));

module.exports = router;
