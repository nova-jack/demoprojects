// src/routes/clients.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/clientsService');
const { idParam, listQuery } = require('../validators/common');
const { clientCreateSchema, clientUpdateSchema } = require('../validators/clients');

const router = express.Router();

router.use(requireAuth);

router.get('/',
  validate({ query: listQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.get('/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.getById(req.params.id)))
);

router.post('/',
  requireRole('Admin', 'Manager'),
  validate({ body: clientCreateSchema }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.create(req.body)))
);

router.patch('/:id',
  requireRole('Admin', 'Manager'),
  validate({ params: idParam, body: clientUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body)))
);

router.delete('/:id',
  requireRole('Admin'),
  validate({ params: idParam }),
  asyncHandler(async (req, res) => { await svc.softDelete(req.params.id); res.status(204).end(); })
);

module.exports = router;
