// src/routes/users.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/usersService');
const { idParam } = require('../validators/common');
const { userUpdateSchema, userListQuery } = require('../validators/users');

const router = express.Router();
router.use(requireAuth);

// All authenticated users can see the team list (for assignee dropdowns etc).
router.get('/',
  validate({ query: userListQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.get('/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.getById(req.params.id)))
);

// Admin-only: edit team member
router.patch('/:id',
  requireRole('Admin'),
  validate({ params: idParam, body: userUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body, req.user.id)))
);

module.exports = router;
