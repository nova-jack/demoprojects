// src/routes/workflow.js
// New surface used by the portal frontend. The legacy /api/projects routes
// stay untouched so the old RCM portal keeps working during migration.

const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/workflowService');
const { idParam } = require('../validators/common');
const v = require('../validators/workflow');

const router = express.Router();
router.use(requireAuth);

// Scoped project list — team members only see their projects (enforced in SQL)
router.get('/projects',
  asyncHandler(async (req, res) => res.json(await svc.listProjects(req.user, req.query))));

router.get('/projects/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.getProject(req.user, req.params.id))));

router.post('/projects',
  requireRole('Admin', 'Manager'),
  validate({ body: v.projectCreate }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.createProject(req.user, req.body))));

router.get('/template',
  asyncHandler(async (req, res) => res.json(await svc.getTemplate())));

router.get('/my-work',
  asyncHandler(async (req, res) => res.json(await svc.myWork(req.user))));

// Steps
router.post('/steps/:id/status',
  validate({ params: idParam, body: v.stepStatus }),
  asyncHandler(async (req, res) => res.json(await svc.setStepStatus(req.user, req.params.id, req.body.status))));

router.patch('/steps/:id',
  validate({ params: idParam, body: v.stepPatch }),
  asyncHandler(async (req, res) => res.json(await svc.updateStep(req.user, req.params.id, req.body))));

// Checklist
router.post('/steps/:id/checklist',
  validate({ params: idParam, body: v.checklistCreate }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.addChecklistItem(req.user, req.params.id, req.body))));

router.post('/checklist/:id/toggle',
  validate({ params: idParam, body: v.checklistToggle }),
  asyncHandler(async (req, res) => res.json(await svc.toggleChecklistItem(req.user, req.params.id, req.body.done))));

router.delete('/checklist/:id',
  validate({ params: idParam }),
  asyncHandler(async (req, res) => res.json(await svc.deleteChecklistItem(req.user, req.params.id))));

// Members & comments
router.post('/projects/:id/members',
  validate({ params: idParam, body: v.memberAdd }),
  asyncHandler(async (req, res) => res.json(await svc.addMember(req.user, req.params.id, req.body.user_id, req.body.role_note))));

router.delete('/projects/:id/members/:userId',
  asyncHandler(async (req, res) => res.json(await svc.removeMember(req.user, req.params.id, req.params.userId))));

router.post('/projects/:id/comments',
  validate({ params: idParam, body: v.comment }),
  asyncHandler(async (req, res) => res.json(await svc.addComment(req.user, req.params.id, req.body.text))));

module.exports = router;
