// src/routes/invoices.js
const express = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/invoicesService');
const { invoiceIdParam } = require('../validators/common');
const {
  invoiceCreateSchema, invoiceUpdateSchema, recordPaymentSchema, invoiceListQuery,
} = require('../validators/invoices');

const router = express.Router();
router.use(requireAuth);

router.get('/',
  validate({ query: invoiceListQuery }),
  asyncHandler(async (req, res) => res.json(await svc.list(req.query)))
);

router.get('/:id',
  validate({ params: invoiceIdParam }),
  asyncHandler(async (req, res) => res.json(await svc.getById(req.params.id)))
);

router.post('/',
  requireRole('Admin', 'Manager'),
  validate({ body: invoiceCreateSchema }),
  asyncHandler(async (req, res) => res.status(201).json(await svc.create(req.body)))
);

router.patch('/:id',
  requireRole('Admin', 'Manager'),
  validate({ params: invoiceIdParam, body: invoiceUpdateSchema }),
  asyncHandler(async (req, res) => res.json(await svc.update(req.params.id, req.body)))
);

router.post('/:id/payments',
  requireRole('Admin', 'Manager'),
  validate({ params: invoiceIdParam, body: recordPaymentSchema }),
  asyncHandler(async (req, res) => res.json(await svc.recordPayment(req.params.id, req.body.amount)))
);

router.delete('/:id',
  requireRole('Admin'),
  validate({ params: invoiceIdParam }),
  asyncHandler(async (req, res) => { await svc.remove(req.params.id); res.status(204).end(); })
);

module.exports = router;
