// src/routes/dashboard.js
const express = require('express');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/dashboardService');

const router = express.Router();
router.use(requireAuth);

router.get('/', asyncHandler(async (req, res) => res.json(await svc.getSummary())));

module.exports = router;
