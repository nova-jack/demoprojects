// src/db/pool.js
// Single shared pg Pool. Use query() for simple queries, withTransaction() for atomic multi-step ops.

const { Pool } = require('pg');
const env = require('../config/env');
const logger = require('../config/logger');

const poolConfig = env.DATABASE_URL
  ? { connectionString: env.DATABASE_URL }
  : {
      host: env.PGHOST,
      port: env.PGPORT,
      database: env.PGDATABASE,
      user: env.PGUSER,
      password: env.PGPASSWORD,
    };

const pool = new Pool({
  ...poolConfig,
  max: 20,                        // tune based on load
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  statement_timeout: 10_000,      // kill any query stuck >10s
  ssl: env.isProd ? { rejectUnauthorized: false } : false,
});

pool.on('error', (err) => {
  // Idle client errors. Don't crash, just log — pg will replace the client.
  logger.error({ err }, 'Unexpected error on idle pg client');
});

/** Run a single query. Always use parameterized values ($1, $2, ...). */
async function query(text, params) {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const ms = Date.now() - start;
    if (ms > 500) logger.warn({ ms, text, rows: result.rowCount }, 'Slow query');
    return result;
  } catch (err) {
    logger.error({ err, text }, 'Query failed');
    throw err;
  }
}

/**
 * Run a function inside a transaction. Auto-commits on success, rolls back on throw.
 * Usage:
 *   await withTransaction(async (client) => {
 *     await client.query('INSERT ...');
 *     await client.query('UPDATE ...');
 *   });
 */
async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

async function close() {
  await pool.end();
}

module.exports = { pool, query, withTransaction, close };
