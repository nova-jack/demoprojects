// src/utils/sqlBuilders.js
// Tiny helpers for building dynamic SQL safely. Always parameterized.

/**
 * Build an UPDATE ... SET clause from an object of fields.
 *   buildUpdate({name:'X', email:'y@z'}, ['name','email'])
 *   → { setSql: '"name" = $1, "email" = $2', values: ['X','y@z'] }
 *
 * `allowed` whitelists which keys can be updated — never trust the request body
 * to decide which columns to touch.
 */
function buildUpdate(input, allowed, startIndex = 1) {
  const sets = [];
  const values = [];
  let i = startIndex;
  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(input, key)) {
      sets.push(`"${key}" = $${i++}`);
      values.push(input[key]);
    }
  }
  return { setSql: sets.join(', '), values, nextIndex: i };
}

/**
 * Parse "field:dir" sort param against a whitelist.
 *   parseSort("created_at:desc", ["created_at","name"])
 *   → "created_at DESC"
 * Falls back to the default if input is invalid or not whitelisted.
 */
function parseSort(input, allowed, defaultSort = 'created_at DESC') {
  if (!input) return defaultSort;
  const [field, dir = 'asc'] = String(input).split(':');
  if (!allowed.includes(field)) return defaultSort;
  const direction = dir.toLowerCase() === 'desc' ? 'DESC' : 'ASC';
  return `"${field}" ${direction}`;
}

module.exports = { buildUpdate, parseSort };
