// src/utils/asyncHandler.js
// Wraps async route handlers so thrown errors flow into Express's error middleware.
// Usage: router.get('/x', asyncHandler(async (req, res) => { ... }));
module.exports = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};
