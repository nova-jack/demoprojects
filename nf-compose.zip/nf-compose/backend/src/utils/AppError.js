// src/utils/AppError.js
// Throw these from anywhere; the error middleware turns them into clean HTTP responses.
// Anything that isn't an AppError is treated as 500 and logged with a stack trace.

class AppError extends Error {
  constructor(message, statusCode = 500, code = 'INTERNAL_ERROR', details = undefined) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = true; // i.e. expected, not a bug
    Error.captureStackTrace?.(this, this.constructor);
  }

  static badRequest(msg = 'Bad request', details) { return new AppError(msg, 400, 'BAD_REQUEST', details); }
  static unauthorized(msg = 'Unauthorized')        { return new AppError(msg, 401, 'UNAUTHORIZED'); }
  static forbidden(msg = 'Forbidden')              { return new AppError(msg, 403, 'FORBIDDEN'); }
  static notFound(msg = 'Not found')               { return new AppError(msg, 404, 'NOT_FOUND'); }
  static conflict(msg = 'Conflict', details)       { return new AppError(msg, 409, 'CONFLICT', details); }
  static validation(msg = 'Validation failed', details) { return new AppError(msg, 422, 'VALIDATION_ERROR', details); }
  static tooManyRequests(msg = 'Too many requests') { return new AppError(msg, 429, 'RATE_LIMITED'); }
}

module.exports = AppError;
