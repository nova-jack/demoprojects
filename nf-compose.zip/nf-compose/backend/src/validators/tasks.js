// src/validators/tasks.js
const { z } = require('zod');
const { listQuery, dateOnly, priority } = require('./common');

const taskCreateSchema = z.object({
  title:       z.string().trim().min(1).max(200),
  project_id:  z.coerce.number().int().positive().optional().nullable(),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  due_date:    dateOnly.optional().nullable(),
  priority:    priority.default('Medium'),
});

const taskUpdateSchema = z.object({
  title:       z.string().trim().min(1).max(200).optional(),
  project_id:  z.coerce.number().int().positive().optional().nullable(),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  due_date:    dateOnly.optional().nullable(),
  priority:    priority.optional(),
  done:        z.boolean().optional(),
}).refine((v) => Object.keys(v).length > 0, { message: 'At least one field required' });

const taskListQuery = listQuery.extend({
  project_id:  z.coerce.number().int().positive().optional(),
  assignee_id: z.coerce.number().int().positive().optional(),
  done:        z.coerce.boolean().optional(),
  priority:    priority.optional(),
});

module.exports = { taskCreateSchema, taskUpdateSchema, taskListQuery };
