// src/validators/expenses.js
const { z } = require('zod');
const { listQuery, money, dateOnly } = require('./common');

const expenseCreateSchema = z.object({
  category:     z.string().trim().min(1).max(50),
  amount:       money,
  icon:         z.string().trim().max(10).optional().nullable(),
  expense_date: dateOnly.optional(),
  notes:        z.string().trim().max(500).optional().nullable(),
});

const expenseUpdateSchema = expenseCreateSchema.partial()
  .refine((v) => Object.keys(v).length > 0, { message: 'At least one field required' });

const expenseListQuery = listQuery.extend({
  category: z.string().optional(),
  from:     dateOnly.optional(),
  to:       dateOnly.optional(),
});

module.exports = { expenseCreateSchema, expenseUpdateSchema, expenseListQuery };
