// src/validators/clients.js
const { z } = require('zod');
const { listQuery } = require('./common');

const clientCreateSchema = z.object({
  name:    z.string().trim().min(1).max(100),
  company: z.string().trim().max(100).optional().nullable(),
  phone:   z.string().trim().max(20).optional().nullable(),
  email:   z.string().email().toLowerCase().optional().nullable(),
  gst:     z.string().trim().max(20).optional().nullable(),
  city:    z.string().trim().max(100).optional().nullable(),
  address: z.string().trim().max(500).optional().nullable(),
  notes:   z.string().trim().max(2000).optional().nullable(),
  color:   z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
});

// Update: same fields, all optional, but at least one must be present
const clientUpdateSchema = clientCreateSchema.partial().refine(
  (obj) => Object.keys(obj).length > 0,
  { message: 'At least one field is required' }
);

module.exports = { clientCreateSchema, clientUpdateSchema, clientListQuery: listQuery };
