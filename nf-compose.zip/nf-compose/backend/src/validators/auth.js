// src/validators/auth.js
const { z } = require('zod');
const { role } = require('./common');

const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters')
  .max(128, 'Password too long');

const loginSchema = z.object({
  email:    z.string().email().toLowerCase(),
  password: z.string().min(1, 'Password required'),
});

const registerSchema = z.object({
  name:     z.string().trim().min(2).max(100),
  email:    z.string().email().toLowerCase(),
  password: passwordSchema,
  phone:    z.string().trim().max(20).optional(),
  role:     role.default('Staff'),
  dept:     z.string().trim().max(50).optional(),
});

const refreshSchema = z.object({
  refreshToken: z.string().min(20),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword:     passwordSchema,
});

module.exports = { loginSchema, registerSchema, refreshSchema, changePasswordSchema };
