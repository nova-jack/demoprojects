// src/validators/common.js
const { z } = require('zod');

// IDs from URL params arrive as strings; coerce to positive integer.
const idParam = z.object({
  id: z.coerce.number().int().positive(),
});

const invoiceIdParam = z.object({
  id: z.string().regex(/^INV-\d+$/, 'Invalid invoice id (expected format: INV-<number>)'),
});

// Pagination + sorting query params (used by list endpoints)
const listQuery = z.object({
  page:   z.coerce.number().int().positive().default(1),
  limit:  z.coerce.number().int().positive().max(100).default(20),
  sort:   z.string().optional(),    // e.g. "created_at:desc"
  q:      z.string().trim().optional(), // search
});

// Money: positive number with up to 2 decimals
const money = z.coerce.number().nonnegative().multipleOf(0.01);

// Optional ISO date string (YYYY-MM-DD)
const dateOnly = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD');

const priority = z.enum(['High', 'Medium', 'Low']);
const role     = z.enum(['Admin', 'Manager', 'Editor', 'Staff']);

module.exports = { idParam, invoiceIdParam, listQuery, money, dateOnly, priority, role };
