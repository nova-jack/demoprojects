// src/validators/workflow.js
const { z } = require('zod');
const { money, dateOnly, priority } = require('./common');

const stepDef = z.union([
  z.string().trim().min(1).max(120),
  z.object({
    name: z.string().trim().min(1).max(120),
    assignee_id: z.coerce.number().int().positive().optional().nullable(),
    due_date: dateOnly.optional().nullable(),
  }),
]);

const projectCreate = z.object({
  name:        z.string().trim().min(1).max(200),
  client_id:   z.coerce.number().int().positive(),
  type:        z.string().trim().max(50).optional().nullable(),
  amount:      money.default(0),
  priority:    priority.default('Medium'),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  start_date:  dateOnly.optional().nullable(),
  deadline:    dateOnly.optional().nullable(),
  description: z.string().trim().max(2000).optional().nullable(),
  steps:       z.array(stepDef).max(20).optional(),
  member_ids:  z.array(z.coerce.number().int().positive()).max(50).optional(),
});

const stepStatus = z.object({ status: z.enum(['pending', 'active', 'done']) });

const stepPatch = z.object({
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  due_date:    dateOnly.optional().nullable(),
  notes:       z.string().trim().max(2000).optional().nullable(),
});

const checklistCreate = z.object({
  title:       z.string().trim().min(1).max(300),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
});

const checklistToggle = z.object({ done: z.boolean() });

const memberAdd = z.object({
  user_id:   z.coerce.number().int().positive(),
  role_note: z.string().trim().max(120).optional().nullable(),
});

const comment = z.object({ text: z.string().trim().min(1).max(2000) });

const expenseCreate = z.object({
  category:     z.string().trim().min(1).max(120),
  amount:       money,
  expense_date: dateOnly.optional(),
  notes:        z.string().trim().max(1000).optional().nullable(),
  expense_type: z.enum(['company_bill', 'staff_payment', 'project_expense', 'other']).default('other'),
  user_id:      z.coerce.number().int().positive().optional().nullable(),
  project_id:   z.coerce.number().int().positive().optional().nullable(),
});

module.exports = { projectCreate, stepStatus, stepPatch, checklistCreate, checklistToggle, memberAdd, comment, expenseCreate };
