// src/validators/invoices.js
const { z } = require('zod');
const { listQuery, money, dateOnly } = require('./common');

const invoiceItemSchema = z.object({
  project_id:  z.coerce.number().int().positive().optional().nullable(),
  description: z.string().trim().min(1).max(500),
  amount:      money,
});

const invoiceCreateSchema = z.object({
  client_id:    z.coerce.number().int().positive(),
  invoice_date: dateOnly,
  due_date:     dateOnly,
  gst_rate:     z.coerce.number().min(0).max(100).default(18),
  notes:        z.string().trim().max(2000).optional().nullable(),
  items:        z.array(invoiceItemSchema).min(1, 'Invoice must have at least one item'),
}).refine((v) => v.due_date >= v.invoice_date, {
  message: 'due_date must be on or after invoice_date',
  path: ['due_date'],
});

const invoiceUpdateSchema = z.object({
  invoice_date: dateOnly.optional(),
  due_date:     dateOnly.optional(),
  gst_rate:     z.coerce.number().min(0).max(100).optional(),
  notes:        z.string().trim().max(2000).optional().nullable(),
  items:        z.array(invoiceItemSchema).min(1).optional(),
}).refine((obj) => Object.keys(obj).length > 0, { message: 'At least one field required' });

const recordPaymentSchema = z.object({
  amount: money.refine((n) => n > 0, { message: 'Payment must be > 0' }),
});

const invoiceListQuery = listQuery.extend({
  client_id: z.coerce.number().int().positive().optional(),
  status:    z.enum(['Paid', 'Unpaid', 'Partial']).optional(),
});

module.exports = {
  invoiceCreateSchema, invoiceUpdateSchema, recordPaymentSchema, invoiceListQuery,
};
