// src/validators/projects.js
const { z } = require('zod');
const { listQuery, money, dateOnly, priority } = require('./common');

const projectCreateSchema = z.object({
  name:        z.string().trim().min(1).max(200),
  client_id:   z.coerce.number().int().positive(),
  type:        z.string().trim().max(50).optional().nullable(),
  amount:      money.default(0),
  paid_amount: money.default(0),
  stage:       z.coerce.number().int().min(1).max(9).default(1),
  priority:    priority.default('Medium'),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  start_date:  dateOnly.optional().nullable(),
  deadline:    dateOnly.optional().nullable(),
  description: z.string().trim().max(2000).optional().nullable(),
}).refine((v) => v.paid_amount <= v.amount, {
  message: 'paid_amount cannot exceed amount',
  path: ['paid_amount'],
});

const projectUpdateSchema = z.object({
  name:        z.string().trim().min(1).max(200).optional(),
  client_id:   z.coerce.number().int().positive().optional(),
  type:        z.string().trim().max(50).optional().nullable(),
  amount:      money.optional(),
  paid_amount: money.optional(),
  stage:       z.coerce.number().int().min(1).max(9).optional(),
  priority:    priority.optional(),
  assignee_id: z.coerce.number().int().positive().optional().nullable(),
  start_date:  dateOnly.optional().nullable(),
  deadline:    dateOnly.optional().nullable(),
  description: z.string().trim().max(2000).optional().nullable(),
}).refine((obj) => Object.keys(obj).length > 0, { message: 'At least one field required' });

const projectListQuery = listQuery.extend({
  client_id:   z.coerce.number().int().positive().optional(),
  assignee_id: z.coerce.number().int().positive().optional(),
  stage:       z.coerce.number().int().min(1).max(9).optional(),
  priority:    priority.optional(),
  payment:     z.enum(['Paid', 'Unpaid', 'Partial']).optional(),
});

module.exports = { projectCreateSchema, projectUpdateSchema, projectListQuery };
