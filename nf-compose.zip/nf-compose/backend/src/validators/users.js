// src/validators/users.js
const { z } = require('zod');
const { role, listQuery } = require('./common');

const userUpdateSchema = z.object({
  name:      z.string().trim().min(2).max(100).optional(),
  phone:     z.string().trim().max(20).optional().nullable(),
  role:      role.optional(),
  dept:      z.string().trim().max(50).optional().nullable(),
  color:     z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  is_active: z.boolean().optional(),
}).refine((v) => Object.keys(v).length > 0, { message: 'At least one field required' });

module.exports = { userUpdateSchema, userListQuery: listQuery };
