// src/services/workflowService.js
// Project workflow: pipeline steps, checklists, members, activity timeline.
// Every read is scoped through middleware/scope.js so Staff/Editor only ever
// receive rows for projects they're on. Money fields are stripped server-side
// for non-elevated roles — never trust the frontend to hide them.

const { query, withTransaction } = require('../db/pool');
const AppError = require('../utils/AppError');
const { isElevated, projectScopeSql, assertProjectAccess, redactProject } = require('../middleware/scope');

const DEFAULT_TEMPLATE = ['Requirement', 'Graphics', 'Shoot', 'Gather Data', 'Edit', 'Review', 'Changes', 'Final Submit'];

async function log(client, projectId, userId, action, detail) {
  const q = client ? client.query.bind(client) : query;
  await q(
    'INSERT INTO activity_log (project_id, user_id, action, detail) VALUES ($1,$2,$3,$4)',
    [projectId, userId ? Number(userId) : null, action, detail || null]
  );
}

async function getTemplate() {
  const { rows } = await query(`SELECT value FROM app_settings WHERE key = 'workflow_template'`);
  const t = rows[0]?.value;
  return Array.isArray(t) && t.length ? t : DEFAULT_TEMPLATE;
}

// ── Project list (scoped, with pipeline progress) ───────────
async function listProjects(user, q) {
  const params = [];
  const filters = ['p.deleted_at IS NULL'];
  if (q.q)      { params.push(`%${q.q}%`); filters.push(`(p.name ILIKE $${params.length} OR c.name ILIKE $${params.length})`); }
  if (q.status === 'active') filters.push(`EXISTS (SELECT 1 FROM workflow_steps s WHERE s.project_id = p.id AND s.status <> 'done')`);
  if (q.status === 'done')   filters.push(`NOT EXISTS (SELECT 1 FROM workflow_steps s WHERE s.project_id = p.id AND s.status <> 'done')`);
  const scope = projectScopeSql(user, params);

  const { rows } = await query(
    `SELECT p.id, p.name, p.description, p.priority, p.deadline, p.start_date, p.type,
            p.amount, p.paid_amount, p.created_at,
            c.name AS client_name,
            u.name AS assignee_name,
            (SELECT count(*)::int FROM workflow_steps s WHERE s.project_id = p.id)                       AS steps_total,
            (SELECT count(*)::int FROM workflow_steps s WHERE s.project_id = p.id AND s.status = 'done') AS steps_done,
            (SELECT s.name FROM workflow_steps s WHERE s.project_id = p.id AND s.status = 'active'
              ORDER BY s.position LIMIT 1) AS current_step,
            (SELECT coalesce(json_agg(json_build_object('id', mu.id, 'name', mu.name, 'color', mu.color)), '[]'::json)
               FROM project_members pm JOIN users mu ON mu.id = pm.user_id
              WHERE pm.project_id = p.id) AS members
     FROM projects p
     JOIN clients c ON c.id = p.client_id
     LEFT JOIN users u ON u.id = p.assignee_id
     WHERE ${filters.join(' AND ')} ${scope}
     ORDER BY (p.deadline IS NULL), p.deadline ASC, p.created_at DESC
     LIMIT 200`,
    params
  );
  return rows.map((r) => redactProject(user, r));
}

// ── Project detail (steps + checklists + members + timeline + files) ─
async function getProject(user, id) {
  const project = await assertProjectAccess(user, id);

  const [client, steps, checks, members, activity, files] = await Promise.all([
    query('SELECT id, name, company, phone, email, city FROM clients WHERE id = $1', [project.client_id]),
    query(
      `SELECT s.*, u.name AS assignee_name, u.color AS assignee_color
       FROM workflow_steps s LEFT JOIN users u ON u.id = s.assignee_id
       WHERE s.project_id = $1 ORDER BY s.position`, [id]),
    query(
      `SELECT ci.*, u.name AS assignee_name
       FROM checklist_items ci
       JOIN workflow_steps s ON s.id = ci.step_id
       LEFT JOIN users u ON u.id = ci.assignee_id
       WHERE s.project_id = $1 ORDER BY ci.position, ci.id`, [id]),
    query(
      `SELECT u.id, u.name, u.role, u.color, pm.role_note
       FROM project_members pm JOIN users u ON u.id = pm.user_id
       WHERE pm.project_id = $1 ORDER BY u.name`, [id]),
    query(
      `SELECT a.*, u.name AS user_name
       FROM activity_log a LEFT JOIN users u ON u.id = a.user_id
       WHERE a.project_id = $1 ORDER BY a.created_at DESC LIMIT 80`, [id]),
    query(
      `SELECT a.id, a.original_name, a.mime, a.size_bytes, a.created_at, u.name AS uploaded_by_name
       FROM attachments a LEFT JOIN users u ON u.id = a.uploaded_by
       WHERE a.entity_type = 'project' AND a.entity_id = $1 ORDER BY a.created_at DESC`, [id]),
  ]);

  const stepRows = steps.rows.map((s) => ({
    ...s,
    checklist: checks.rows.filter((c) => c.step_id === s.id),
  }));

  return {
    project: redactProject(user, project),
    client: client.rows[0] || null,
    steps: stepRows,
    members: members.rows,
    activity: activity.rows,
    files: files.rows,
    canManage: isElevated(user),
  };
}

// ── Create project with pipeline (Manager/Admin) ────────────
async function createProject(user, body) {
  const stepNames = (body.steps && body.steps.length ? body.steps : await getTemplate());

  return withTransaction(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO projects (name, client_id, type, amount, priority, assignee_id, start_date, deadline, description)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [body.name, body.client_id, body.type || null, body.amount || 0, body.priority || 'Medium',
       body.assignee_id || null, body.start_date || null, body.deadline || null, body.description || null]
    );
    const project = rows[0];

    for (let i = 0; i < stepNames.length; i++) {
      const s = stepNames[i];
      const name = typeof s === 'string' ? s : s.name;
      const assignee = typeof s === 'object' ? s.assignee_id || null : null;
      const due = typeof s === 'object' ? s.due_date || null : null;
      await client.query(
        `INSERT INTO workflow_steps (project_id, position, name, status, assignee_id, due_date, started_at)
         VALUES ($1,$2,$3,$4,$5,$6, CASE WHEN $4 = 'active' THEN now() END)`,
        [project.id, i + 1, name, i === 0 ? 'active' : 'pending', assignee, due]
      );
    }

    const memberIds = [...new Set((body.member_ids || []).map(Number))];
    for (const uid of memberIds) {
      await client.query(
        'INSERT INTO project_members (project_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',
        [project.id, uid]
      );
    }

    await log(client, project.id, user.id, 'created', `Project created with ${stepNames.length} pipeline steps`);
    return project;
  });
}

// ── Step transitions ────────────────────────────────────────
// Team members can move their own step; Manager/Admin can move any.
// Completing a step auto-activates the next pending one → that's the timeline.
async function setStepStatus(user, stepId, status) {
  const { rows } = await query('SELECT * FROM workflow_steps WHERE id = $1', [stepId]);
  const step = rows[0];
  if (!step) throw AppError.notFound('Step not found');
  await assertProjectAccess(user, step.project_id);

  const mine = step.assignee_id != null && Number(step.assignee_id) === Number(user.id);
  if (!isElevated(user) && !mine) throw AppError.forbidden('Only the step assignee or a manager can update this step');

  return withTransaction(async (client) => {
    await client.query(
      `UPDATE workflow_steps SET status = $2,
         started_at = CASE WHEN $2 IN ('active','done') THEN coalesce(started_at, now()) ELSE started_at END,
         done_at    = CASE WHEN $2 = 'done' THEN now() ELSE NULL END
       WHERE id = $1`,
      [stepId, status]
    );

    if (status === 'done') {
      // auto-advance: activate the next pending step, if any
      const nxt = await client.query(
        `UPDATE workflow_steps SET status = 'active', started_at = coalesce(started_at, now())
         WHERE id = (SELECT id FROM workflow_steps
                     WHERE project_id = $1 AND status = 'pending' AND position > $2
                     ORDER BY position LIMIT 1)
         RETURNING name`,
        [step.project_id, step.position]
      );
      await log(client, step.project_id, user.id, 'step_done',
        `"${step.name}" completed${nxt.rows[0] ? ` — "${nxt.rows[0].name}" is now active` : ' — pipeline finished 🎉'}`);
    } else {
      await log(client, step.project_id, user.id, status === 'active' ? 'step_started' : 'step_reopened',
        `"${step.name}" → ${status}`);
    }
    return { ok: true };
  });
}

async function updateStep(user, stepId, patch) {
  if (!isElevated(user)) throw AppError.forbidden('Only managers can edit step details');
  const { rows } = await query('SELECT * FROM workflow_steps WHERE id = $1', [stepId]);
  if (!rows[0]) throw AppError.notFound('Step not found');
  await query(
    `UPDATE workflow_steps SET
       assignee_id = coalesce($2, assignee_id),
       due_date    = coalesce($3, due_date),
       notes       = coalesce($4, notes)
     WHERE id = $1`,
    [stepId, patch.assignee_id ?? null, patch.due_date ?? null, patch.notes ?? null]
  );
  if (patch.assignee_id) {
    await log(null, rows[0].project_id, user.id, 'step_assigned', `"${rows[0].name}" assigned`);
    // Being assigned a step grants visibility; also add as member for clarity.
    await query('INSERT INTO project_members (project_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',
      [rows[0].project_id, patch.assignee_id]);
  }
  return { ok: true };
}

// ── Checklist ───────────────────────────────────────────────
async function addChecklistItem(user, stepId, { title, assignee_id }) {
  const { rows } = await query('SELECT * FROM workflow_steps WHERE id = $1', [stepId]);
  const step = rows[0];
  if (!step) throw AppError.notFound('Step not found');
  await assertProjectAccess(user, step.project_id);
  const mine = step.assignee_id != null && Number(step.assignee_id) === Number(user.id);
  if (!isElevated(user) && !mine) throw AppError.forbidden('Only the step assignee or a manager can add items');

  const { rows: item } = await query(
    `INSERT INTO checklist_items (step_id, title, assignee_id, position)
     VALUES ($1,$2,$3,(SELECT coalesce(max(position),0)+1 FROM checklist_items WHERE step_id = $1))
     RETURNING *`,
    [stepId, title, assignee_id || null]
  );
  if (assignee_id) {
    await query('INSERT INTO project_members (project_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',
      [step.project_id, assignee_id]);
  }
  await log(null, step.project_id, user.id, 'checklist_added', `"${title}" added to "${step.name}"`);
  return item[0];
}

async function toggleChecklistItem(user, itemId, done) {
  const { rows } = await query(
    `SELECT ci.*, s.project_id, s.name AS step_name, s.assignee_id AS step_assignee
     FROM checklist_items ci JOIN workflow_steps s ON s.id = ci.step_id WHERE ci.id = $1`, [itemId]);
  const it = rows[0];
  if (!it) throw AppError.notFound('Checklist item not found');
  await assertProjectAccess(user, it.project_id);

  const uid = Number(user.id);
  const allowed = isElevated(user)
    || (it.assignee_id != null && Number(it.assignee_id) === uid)
    || (it.step_assignee != null && Number(it.step_assignee) === uid);
  if (!allowed) throw AppError.forbidden('This item is assigned to someone else');

  await query(
    `UPDATE checklist_items SET done = $2,
       done_at = CASE WHEN $2 THEN now() END,
       done_by = CASE WHEN $2 THEN $3::bigint END
     WHERE id = $1`,
    [itemId, !!done, uid]
  );
  if (done) await log(null, it.project_id, user.id, 'checklist_done', `"${it.title}" ✓ (${it.step_name})`);
  return { ok: true };
}

async function deleteChecklistItem(user, itemId) {
  if (!isElevated(user)) throw AppError.forbidden('Only managers can delete checklist items');
  await query('DELETE FROM checklist_items WHERE id = $1', [itemId]);
  return { ok: true };
}

// ── Members & comments ──────────────────────────────────────
async function addMember(user, projectId, userId, roleNote) {
  if (!isElevated(user)) throw AppError.forbidden('Only managers can add members');
  await query('INSERT INTO project_members (project_id, user_id, role_note) VALUES ($1,$2,$3) ON CONFLICT (project_id, user_id) DO UPDATE SET role_note = $3',
    [projectId, userId, roleNote || null]);
  const { rows } = await query('SELECT name FROM users WHERE id = $1', [userId]);
  await log(null, projectId, user.id, 'member_added', `${rows[0]?.name || 'User'} added to project`);
  return { ok: true };
}

async function removeMember(user, projectId, userId) {
  if (!isElevated(user)) throw AppError.forbidden('Only managers can remove members');
  await query('DELETE FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, userId]);
  return { ok: true };
}

async function addComment(user, projectId, text) {
  await assertProjectAccess(user, projectId);
  await log(null, projectId, user.id, 'comment', text);
  return { ok: true };
}

// ── "My work" — everything assigned to me across projects ───
async function myWork(user) {
  const uid = Number(user.id);
  const [steps, items] = await Promise.all([
    query(
      `SELECT s.id, s.name, s.status, s.due_date, p.id AS project_id, p.name AS project_name
       FROM workflow_steps s JOIN projects p ON p.id = s.project_id AND p.deleted_at IS NULL
       WHERE s.assignee_id = $1 AND s.status <> 'done'
       ORDER BY (s.due_date IS NULL), s.due_date, s.position`, [uid]),
    query(
      `SELECT ci.id, ci.title, ci.done, s.name AS step_name, p.id AS project_id, p.name AS project_name
       FROM checklist_items ci
       JOIN workflow_steps s ON s.id = ci.step_id
       JOIN projects p ON p.id = s.project_id AND p.deleted_at IS NULL
       WHERE ci.assignee_id = $1 AND ci.done = false
       ORDER BY ci.created_at`, [uid]),
  ]);
  return { steps: steps.rows, checklist: items.rows };
}

module.exports = {
  listProjects, getProject, createProject, setStepStatus, updateStep,
  addChecklistItem, toggleChecklistItem, deleteChecklistItem,
  addMember, removeMember, addComment, myWork, getTemplate,
};
