// src/services/projectsService.js
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { buildUpdate, parseSort } = require('../utils/sqlBuilders');

const ALLOWED_FIELDS = [
  'name', 'client_id', 'type', 'amount', 'paid_amount', 'stage',
  'priority', 'assignee_id', 'start_date', 'deadline', 'description',
];
const SORTABLE = ['name', 'amount', 'deadline', 'stage', 'created_at', 'updated_at'];

// Use the v_projects view so payment status comes back computed.
async function list(q) {
  const { page, limit, sort } = q;
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];
  if (q.q)           { params.push(`%${q.q}%`);    filters.push(`(p.name ILIKE $${params.length} OR p.type ILIKE $${params.length})`); }
  if (q.client_id)   { params.push(q.client_id);   filters.push(`p.client_id = $${params.length}`); }
  if (q.assignee_id) { params.push(q.assignee_id); filters.push(`p.assignee_id = $${params.length}`); }
  if (q.stage)       { params.push(q.stage);       filters.push(`p.stage = $${params.length}`); }
  if (q.priority)    { params.push(q.priority);    filters.push(`p.priority = $${params.length}`); }
  if (q.payment)     { params.push(q.payment);     filters.push(`p.payment = $${params.length}`); }

  const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  const orderBy = parseSort(sort, SORTABLE, 'created_at DESC').replace(/^"?(\w+)"?/, 'p."$1"');

  params.push(limit, offset);
  const limitParam = params.length - 1;
  const offsetParam = params.length;

  const itemsSql = `
    SELECT p.*,
           c.name AS client_name, c.company AS client_company,
           u.name AS assignee_name
    FROM v_projects p
    JOIN clients c ON c.id = p.client_id
    LEFT JOIN users u ON u.id = p.assignee_id
    ${whereSql}
    ORDER BY ${orderBy}
    LIMIT $${limitParam} OFFSET $${offsetParam}
  `;
  const countSql = `SELECT count(*)::int AS total FROM v_projects p ${whereSql}`;
  const countParams = params.slice(0, params.length - 2);

  const [items, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);

  return { items: items.rows, page, limit, total: count.rows[0].total };
}

async function getById(id) {
  const { rows } = await query(
    `SELECT p.*, c.name AS client_name, c.company AS client_company, u.name AS assignee_name
     FROM v_projects p
     JOIN clients c ON c.id = p.client_id
     LEFT JOIN users u ON u.id = p.assignee_id
     WHERE p.id = $1`,
    [id]
  );
  if (rows.length === 0) throw AppError.notFound('Project not found');
  return rows[0];
}

async function create(input) {
  const cols = ALLOWED_FIELDS.filter((f) => input[f] !== undefined);
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(', ');
  const values = cols.map((f) => input[f]);
  const { rows } = await query(
    `INSERT INTO projects (${cols.map((c) => `"${c}"`).join(', ')})
     VALUES (${placeholders})
     RETURNING *`,
    values
  );
  return getById(rows[0].id);
}

async function update(id, input) {
  const { setSql, values } = buildUpdate(input, ALLOWED_FIELDS);
  if (!setSql) throw AppError.badRequest('No valid fields to update');
  values.push(id);
  const { rows } = await query(
    `UPDATE projects SET ${setSql}
     WHERE id = $${values.length} AND deleted_at IS NULL
     RETURNING id`,
    values
  );
  if (rows.length === 0) throw AppError.notFound('Project not found');
  return getById(id);
}

async function softDelete(id) {
  const { rows } = await query(
    `UPDATE projects SET deleted_at = now()
     WHERE id = $1 AND deleted_at IS NULL RETURNING id`,
    [id]
  );
  if (rows.length === 0) throw AppError.notFound('Project not found');
}

module.exports = { list, getById, create, update, softDelete };
