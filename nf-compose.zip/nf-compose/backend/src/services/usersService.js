// src/services/usersService.js
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { buildUpdate } = require('../utils/sqlBuilders');

const PUBLIC_FIELDS = `id, name, email, phone, role, dept, color, is_active, last_login_at, created_at, updated_at`;
const ALLOWED_FIELDS = ['name', 'phone', 'role', 'dept', 'color', 'is_active'];

async function list(q) {
  const { page, limit } = q;
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];
  if (q.q) { params.push(`%${q.q}%`); filters.push(`(name ILIKE $${params.length} OR email::text ILIKE $${params.length})`); }
  const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  params.push(limit, offset);

  const itemsSql = `
    SELECT ${PUBLIC_FIELDS},
           (SELECT count(*)::int FROM tasks WHERE assignee_id = users.id AND done = false) AS open_tasks,
           (SELECT count(*)::int FROM projects WHERE assignee_id = users.id AND deleted_at IS NULL) AS active_projects
    FROM users ${whereSql}
    ORDER BY name ASC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `;
  const countSql = `SELECT count(*)::int AS total FROM users ${whereSql}`;
  const countParams = params.slice(0, params.length - 2);

  const [items, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);
  return { items: items.rows, page, limit, total: count.rows[0].total };
}

async function getById(id) {
  const { rows } = await query(`SELECT ${PUBLIC_FIELDS} FROM users WHERE id = $1`, [id]);
  if (rows.length === 0) throw AppError.notFound('User not found');
  return rows[0];
}

async function update(id, input, currentUserId) {
  // Don't let an admin demote themselves and lock everyone out
  if (Number(id) === Number(currentUserId) && input.role && input.role !== 'Admin') {
    const { rows } = await query(
      "SELECT count(*)::int AS n FROM users WHERE role = 'Admin' AND is_active = true AND id <> $1",
      [id]
    );
    if (rows[0].n === 0) throw AppError.badRequest('Cannot demote yourself — no other active admin exists');
  }
  if (Number(id) === Number(currentUserId) && input.is_active === false) {
    throw AppError.badRequest('Cannot deactivate yourself');
  }

  const { setSql, values } = buildUpdate(input, ALLOWED_FIELDS);
  if (!setSql) throw AppError.badRequest('No valid fields');
  values.push(id);
  const { rows } = await query(
    `UPDATE users SET ${setSql} WHERE id = $${values.length} RETURNING ${PUBLIC_FIELDS}`,
    values
  );
  if (rows.length === 0) throw AppError.notFound('User not found');
  return rows[0];
}

module.exports = { list, getById, update };
