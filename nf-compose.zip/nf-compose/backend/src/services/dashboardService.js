// src/services/dashboardService.js
// One endpoint to power the dashboard. Runs queries in parallel.

const { query } = require('../db/pool');

async function getSummary() {
  const [
    counts,
    revenue,
    outstanding,
    upcomingDeadlines,
    overdueInvoices,
    revenueByMonth,
    expensesByCategory,
  ] = await Promise.all([
    // Top-line counts
    query(`
      SELECT
        (SELECT count(*)::int FROM clients  WHERE deleted_at IS NULL) AS clients,
        (SELECT count(*)::int FROM projects WHERE deleted_at IS NULL) AS projects,
        (SELECT count(*)::int FROM projects WHERE deleted_at IS NULL AND stage < 9) AS active_projects,
        (SELECT count(*)::int FROM tasks    WHERE done = false) AS open_tasks,
        (SELECT count(*)::int FROM users    WHERE is_active = true) AS users
    `),

    // Total revenue collected vs quoted (across all projects)
    query(`
      SELECT
        COALESCE(sum(amount), 0)      AS total_quoted,
        COALESCE(sum(paid_amount), 0) AS total_collected
      FROM projects WHERE deleted_at IS NULL
    `),

    // Outstanding from invoices
    query(`
      SELECT
        COALESCE(sum(total - paid_amount), 0) AS outstanding,
        count(*) FILTER (WHERE status <> 'Paid')::int AS unpaid_count,
        count(*) FILTER (WHERE status <> 'Paid' AND due_date < CURRENT_DATE)::int AS overdue_count
      FROM v_invoices
    `),

    // Upcoming project deadlines (next 14 days, not done)
    query(`
      SELECT p.id, p.name, p.deadline, p.priority, c.name AS client_name
      FROM projects p
      JOIN clients c ON c.id = p.client_id
      WHERE p.deleted_at IS NULL
        AND p.stage < 9
        AND p.deadline IS NOT NULL
        AND p.deadline BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '14 days'
      ORDER BY p.deadline ASC
      LIMIT 10
    `),

    // Overdue invoices
    query(`
      SELECT i.id, i.total, i.paid_amount, i.due_date, c.name AS client_name
      FROM v_invoices i
      JOIN clients c ON c.id = i.client_id
      WHERE i.status <> 'Paid' AND i.due_date < CURRENT_DATE
      ORDER BY i.due_date ASC
      LIMIT 10
    `),

    // Last 12 months of revenue (sum of payments by month, derived from project paid_amount + invoice updated_at)
    // Simpler: monthly invoice payments via paid_amount on invoices, bucketed by invoice_date.
    query(`
      WITH months AS (
        SELECT generate_series(
          date_trunc('month', CURRENT_DATE) - INTERVAL '11 months',
          date_trunc('month', CURRENT_DATE),
          '1 month'
        )::date AS month
      )
      SELECT
        to_char(m.month, 'Mon')         AS label,
        to_char(m.month, 'YYYY-MM')     AS ym,
        COALESCE(sum(i.paid_amount), 0) AS revenue
      FROM months m
      LEFT JOIN invoices i
        ON date_trunc('month', i.invoice_date) = m.month
      GROUP BY m.month
      ORDER BY m.month
    `),

    // Expenses by category (current month)
    query(`
      SELECT category, icon, sum(amount) AS amount
      FROM expenses
      WHERE expense_date >= date_trunc('month', CURRENT_DATE)
      GROUP BY category, icon
      ORDER BY amount DESC
    `),
  ]);

  return {
    counts: counts.rows[0],
    revenue: revenue.rows[0],
    outstanding: outstanding.rows[0],
    upcoming_deadlines: upcomingDeadlines.rows,
    overdue_invoices: overdueInvoices.rows,
    revenue_by_month: revenueByMonth.rows,
    expenses_by_category: expensesByCategory.rows,
  };
}

module.exports = { getSummary };
