// src/services/expensesService.js
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { buildUpdate } = require('../utils/sqlBuilders');

const ALLOWED_FIELDS = ['category', 'amount', 'icon', 'expense_date', 'notes'];

async function list(q) {
  const { page, limit } = q;
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];
  if (q.q)        { params.push(`%${q.q}%`); filters.push(`(category ILIKE $${params.length} OR notes ILIKE $${params.length})`); }
  if (q.category) { params.push(q.category); filters.push(`category = $${params.length}`); }
  if (q.from)     { params.push(q.from);     filters.push(`expense_date >= $${params.length}`); }
  if (q.to)       { params.push(q.to);       filters.push(`expense_date <= $${params.length}`); }

  const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  params.push(limit, offset);

  const itemsSql = `
    SELECT * FROM expenses ${whereSql}
    ORDER BY expense_date DESC, id DESC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `;
  const countSql = `SELECT count(*)::int AS total FROM expenses ${whereSql}`;
  const countParams = params.slice(0, params.length - 2);

  const [items, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);
  return { items: items.rows, page, limit, total: count.rows[0].total };
}

async function create(input, userId) {
  const cols = ['category', 'amount', 'icon', 'expense_date', 'notes', 'created_by'];
  const values = [input.category, input.amount, input.icon ?? null, input.expense_date ?? null, input.notes ?? null, userId];
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(', ');
  const { rows } = await query(
    `INSERT INTO expenses (${cols.join(', ')}) VALUES (${placeholders}) RETURNING *`,
    values
  );
  return rows[0];
}

async function update(id, input) {
  const { setSql, values } = buildUpdate(input, ALLOWED_FIELDS);
  if (!setSql) throw AppError.badRequest('No valid fields');
  values.push(id);
  const { rows } = await query(
    `UPDATE expenses SET ${setSql} WHERE id = $${values.length} RETURNING *`,
    values
  );
  if (rows.length === 0) throw AppError.notFound('Expense not found');
  return rows[0];
}

async function remove(id) {
  const { rowCount } = await query('DELETE FROM expenses WHERE id = $1', [id]);
  if (rowCount === 0) throw AppError.notFound('Expense not found');
}

module.exports = { list, create, update, remove };
