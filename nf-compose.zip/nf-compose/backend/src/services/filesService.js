// src/services/filesService.js
// Attachment metadata + disk storage helpers.
// Decision: binaries live on disk (UPLOAD_DIR), never in Postgres. Videos in
// bytea/large-objects bloat WAL, backups and pool memory for zero benefit.
// Swapping this module's read/write for S3/R2 later is a one-file change.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { isElevated, assertProjectAccess } = require('../middleware/scope');

const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const ALLOWED_MIME = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
  'video/mp4', 'video/quicktime', 'video/webm',
  'application/pdf',
]);
const MAX_BYTES = 500 * 1024 * 1024; // 500 MB — raw shoot clips are big

function storedNameFor(originalName) {
  const ext = path.extname(originalName).toLowerCase().slice(0, 10);
  return crypto.randomBytes(16).toString('hex') + ext;
}

async function saveRecord(user, { entityType, entityId, storedName, originalName, mime, size }) {
  if (!ALLOWED_MIME.has(mime)) throw AppError.badRequest(`File type ${mime} not allowed`);
  if (size > MAX_BYTES) throw AppError.badRequest('File exceeds 500 MB limit');

  if (entityType === 'project') {
    await assertProjectAccess(user, entityId);
  } else if (entityType === 'expense') {
    if (!isElevated(user)) throw AppError.forbidden('Only managers can attach files to expenses');
  } else {
    throw AppError.badRequest('Unknown entity type');
  }

  const { rows } = await query(
    `INSERT INTO attachments (entity_type, entity_id, stored_name, original_name, mime, size_bytes, uploaded_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [entityType, entityId, storedName, originalName, mime, size, Number(user.id)]
  );
  if (entityType === 'project') {
    await query('INSERT INTO activity_log (project_id, user_id, action, detail) VALUES ($1,$2,$3,$4)',
      [entityId, Number(user.id), 'file_added', originalName]);
  }
  return rows[0];
}

async function getForRead(user, id) {
  const { rows } = await query('SELECT * FROM attachments WHERE id = $1', [id]);
  const a = rows[0];
  if (!a) throw AppError.notFound('File not found');
  if (a.entity_type === 'project') await assertProjectAccess(user, a.entity_id);
  else if (!isElevated(user)) throw AppError.forbidden('No access to this file');
  const abs = path.join(UPLOAD_DIR, path.basename(a.stored_name)); // basename → no traversal
  if (!fs.existsSync(abs)) throw AppError.notFound('File missing on disk');
  return { meta: a, absPath: abs };
}

async function remove(user, id) {
  const { rows } = await query('SELECT * FROM attachments WHERE id = $1', [id]);
  const a = rows[0];
  if (!a) throw AppError.notFound('File not found');
  const mine = a.uploaded_by != null && Number(a.uploaded_by) === Number(user.id);
  if (!isElevated(user) && !mine) throw AppError.forbidden('Only the uploader or a manager can delete this file');
  await query('DELETE FROM attachments WHERE id = $1', [id]);
  fs.promises.unlink(path.join(UPLOAD_DIR, path.basename(a.stored_name))).catch(() => {});
  return { ok: true };
}

module.exports = { UPLOAD_DIR, ALLOWED_MIME, MAX_BYTES, storedNameFor, saveRecord, getForRead, remove };
