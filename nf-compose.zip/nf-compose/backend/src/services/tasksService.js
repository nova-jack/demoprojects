// src/services/tasksService.js
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { buildUpdate, parseSort } = require('../utils/sqlBuilders');

const ALLOWED_FIELDS = ['title', 'project_id', 'assignee_id', 'due_date', 'priority', 'done'];
const SORTABLE = ['due_date', 'priority', 'created_at', 'title'];

async function list(q) {
  const { page, limit, sort } = q;
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];
  if (q.q)           { params.push(`%${q.q}%`);    filters.push(`t.title ILIKE $${params.length}`); }
  if (q.project_id)  { params.push(q.project_id);  filters.push(`t.project_id = $${params.length}`); }
  if (q.assignee_id) { params.push(q.assignee_id); filters.push(`t.assignee_id = $${params.length}`); }
  if (q.done !== undefined) { params.push(q.done); filters.push(`t.done = $${params.length}`); }
  if (q.priority)    { params.push(q.priority);    filters.push(`t.priority = $${params.length}`); }

  const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  // Default sort: open tasks first, then due date asc
  const orderBy = sort
    ? parseSort(sort, SORTABLE).replace(/^"?(\w+)"?/, 't."$1"')
    : 't.done ASC, t.due_date ASC NULLS LAST';

  params.push(limit, offset);
  const limitParam = params.length - 1;
  const offsetParam = params.length;

  const itemsSql = `
    SELECT t.*,
           p.name AS project_name,
           c.name AS client_name, c.company AS client_company,
           u.name AS assignee_name
    FROM tasks t
    LEFT JOIN projects p ON p.id = t.project_id
    LEFT JOIN clients  c ON c.id = p.client_id
    LEFT JOIN users    u ON u.id = t.assignee_id
    ${whereSql}
    ORDER BY ${orderBy}
    LIMIT $${limitParam} OFFSET $${offsetParam}
  `;
  const countSql = `SELECT count(*)::int AS total FROM tasks t ${whereSql}`;
  const countParams = params.slice(0, params.length - 2);

  const [items, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);
  return { items: items.rows, page, limit, total: count.rows[0].total };
}

async function create(input) {
  const cols = ALLOWED_FIELDS.filter((f) => f !== 'done' && input[f] !== undefined);
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(', ');
  const values = cols.map((f) => input[f]);
  const { rows } = await query(
    `INSERT INTO tasks (${cols.map((c) => `"${c}"`).join(', ')})
     VALUES (${placeholders}) RETURNING *`,
    values
  );
  return rows[0];
}

async function update(id, input) {
  // Track done_at when toggling completion
  const patch = { ...input };
  if (input.done === true)  patch.done_at = new Date();
  if (input.done === false) patch.done_at = null;

  const fields = [...ALLOWED_FIELDS, 'done_at'];
  const { setSql, values } = buildUpdate(patch, fields);
  if (!setSql) throw AppError.badRequest('No valid fields to update');
  values.push(id);
  const { rows } = await query(
    `UPDATE tasks SET ${setSql} WHERE id = $${values.length} RETURNING *`,
    values
  );
  if (rows.length === 0) throw AppError.notFound('Task not found');
  return rows[0];
}

async function remove(id) {
  const { rowCount } = await query('DELETE FROM tasks WHERE id = $1', [id]);
  if (rowCount === 0) throw AppError.notFound('Task not found');
}

module.exports = { list, create, update, remove };
