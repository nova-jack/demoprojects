// src/services/clientsService.js
const { query } = require('../db/pool');
const AppError = require('../utils/AppError');
const { buildUpdate, parseSort } = require('../utils/sqlBuilders');

const ALLOWED_FIELDS = ['name', 'company', 'phone', 'email', 'gst', 'city', 'address', 'notes', 'color'];
const SORTABLE       = ['name', 'company', 'created_at', 'updated_at'];

// Returns clients with computed billing stats. The frontend dashboard needs
// {projects, billing, paid, pending} per client — we get that here in one query.
async function list({ page, limit, sort, q }) {
  const offset = (page - 1) * limit;
  const orderBy = parseSort(sort, SORTABLE, 'name ASC');

  // Search across name/company/email
  const filters = ['c.deleted_at IS NULL'];
  const params = [];
  if (q) {
    params.push(`%${q}%`);
    filters.push(`(c.name ILIKE $${params.length} OR c.company ILIKE $${params.length} OR c.email::text ILIKE $${params.length})`);
  }
  const whereSql = filters.join(' AND ');

  params.push(limit, offset);
  const limitParam = params.length - 1;
  const offsetParam = params.length;

  const itemsSql = `
    SELECT
      c.*,
      COALESCE(p.project_count, 0)::int AS projects,
      COALESCE(p.billing, 0)            AS billing,
      COALESCE(p.paid, 0)               AS paid,
      COALESCE(p.billing, 0) - COALESCE(p.paid, 0) AS pending
    FROM clients c
    LEFT JOIN (
      SELECT client_id,
             count(*)         AS project_count,
             sum(amount)      AS billing,
             sum(paid_amount) AS paid
      FROM projects
      WHERE deleted_at IS NULL
      GROUP BY client_id
    ) p ON p.client_id = c.id
    WHERE ${whereSql}
    ORDER BY ${orderBy.replace(/^"?(\w+)"?/, 'c."$1"')}
    LIMIT $${limitParam} OFFSET $${offsetParam}
  `;

  const countSql = `SELECT count(*)::int AS total FROM clients c WHERE ${whereSql}`;
  // count uses params except limit/offset
  const countParams = params.slice(0, params.length - 2);

  const [items, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);

  return {
    items: items.rows,
    page, limit,
    total: count.rows[0].total,
  };
}

async function getById(id) {
  const { rows } = await query(
    `SELECT
       c.*,
       COALESCE((SELECT count(*) FROM projects WHERE client_id = c.id AND deleted_at IS NULL), 0)::int AS projects,
       COALESCE((SELECT sum(amount) FROM projects WHERE client_id = c.id AND deleted_at IS NULL), 0)   AS billing,
       COALESCE((SELECT sum(paid_amount) FROM projects WHERE client_id = c.id AND deleted_at IS NULL), 0) AS paid
     FROM clients c
     WHERE c.id = $1 AND c.deleted_at IS NULL`,
    [id]
  );
  if (rows.length === 0) throw AppError.notFound('Client not found');
  const c = rows[0];
  c.pending = Number(c.billing) - Number(c.paid);
  return c;
}

async function create(input) {
  const cols = ALLOWED_FIELDS.filter((f) => input[f] !== undefined);
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(', ');
  const values = cols.map((f) => input[f]);
  const { rows } = await query(
    `INSERT INTO clients (${cols.map((c) => `"${c}"`).join(', ')})
     VALUES (${placeholders})
     RETURNING *`,
    values
  );
  return rows[0];
}

async function update(id, input) {
  const { setSql, values } = buildUpdate(input, ALLOWED_FIELDS);
  if (!setSql) throw AppError.badRequest('No valid fields to update');
  values.push(id);
  const { rows } = await query(
    `UPDATE clients SET ${setSql}
     WHERE id = $${values.length} AND deleted_at IS NULL
     RETURNING *`,
    values
  );
  if (rows.length === 0) throw AppError.notFound('Client not found');
  return rows[0];
}

async function softDelete(id) {
  // Refuse if there are non-deleted projects — protects referential integrity
  // visibly to the user instead of triggering a DB constraint error.
  const { rows: prj } = await query(
    'SELECT count(*)::int AS n FROM projects WHERE client_id = $1 AND deleted_at IS NULL',
    [id]
  );
  if (prj[0].n > 0) {
    throw AppError.conflict(`Cannot delete: client has ${prj[0].n} active project(s)`);
  }

  const { rows } = await query(
    `UPDATE clients SET deleted_at = now()
     WHERE id = $1 AND deleted_at IS NULL
     RETURNING id`,
    [id]
  );
  if (rows.length === 0) throw AppError.notFound('Client not found');
}

module.exports = { list, getById, create, update, softDelete };
