// src/services/financeService.js
// Founder (Admin) view: revenue vs spend, growth, staff payments, company bills.
// Revenue = collected money on invoices (paid_amount), attributed to invoice_date.
// Spend   = expenses by expense_type.

const { query } = require('../db/pool');

async function summary() {
  const [rev, exp, byType, monthly, staff, recent] = await Promise.all([
    query(`SELECT coalesce(sum(paid_amount),0)::float AS collected,
                  coalesce(sum(total),0)::float       AS billed,
                  coalesce(sum(total - paid_amount),0)::float AS outstanding
           FROM invoices`),
    query(`SELECT coalesce(sum(amount),0)::float AS total FROM expenses`),
    query(`SELECT expense_type, coalesce(sum(amount),0)::float AS total, count(*)::int AS n
           FROM expenses GROUP BY expense_type`),
    query(`
      WITH months AS (
        SELECT to_char(d, 'YYYY-MM') AS ym
        FROM generate_series(date_trunc('month', now()) - interval '11 months',
                             date_trunc('month', now()), interval '1 month') d
      )
      SELECT m.ym,
        coalesce((SELECT sum(i.paid_amount) FROM invoices i WHERE to_char(i.invoice_date,'YYYY-MM') = m.ym),0)::float AS revenue,
        coalesce((SELECT sum(e.amount)      FROM expenses e WHERE to_char(e.expense_date,'YYYY-MM') = m.ym),0)::float AS expenses
      FROM months m ORDER BY m.ym`),
    query(`SELECT u.id, u.name, coalesce(sum(e.amount),0)::float AS paid, count(e.id)::int AS payments,
                  max(e.expense_date) AS last_paid
           FROM users u JOIN expenses e ON e.user_id = u.id AND e.expense_type = 'staff_payment'
           GROUP BY u.id, u.name ORDER BY paid DESC`),
    query(`SELECT e.*, u.name AS staff_name, p.name AS project_name, cu.name AS created_by_name
           FROM expenses e
           LEFT JOIN users u  ON u.id = e.user_id
           LEFT JOIN projects p ON p.id = e.project_id
           LEFT JOIN users cu ON cu.id = e.created_by
           ORDER BY e.expense_date DESC, e.id DESC LIMIT 100`),
  ]);

  const r = rev.rows[0];
  return {
    collected: r.collected,
    billed: r.billed,
    outstanding: r.outstanding,
    expenses_total: exp.rows[0].total,
    net: r.collected - exp.rows[0].total,
    by_type: byType.rows,
    monthly: monthly.rows,
    staff_payments: staff.rows,
    recent_expenses: recent.rows,
  };
}

async function addExpense(user, body) {
  const { rows } = await query(
    `INSERT INTO expenses (category, amount, expense_date, notes, expense_type, user_id, project_id, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [body.category, body.amount, body.expense_date || new Date().toISOString().slice(0, 10),
     body.notes || null, body.expense_type || 'other', body.user_id || null, body.project_id || null,
     Number(user.id)]
  );
  return rows[0];
}

async function deleteExpense(id) {
  await query('DELETE FROM expenses WHERE id = $1', [id]);
  return { ok: true };
}

module.exports = { summary, addExpense, deleteExpense };
