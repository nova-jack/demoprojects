// src/services/authService.js
// All auth logic lives here. Controllers just call these functions.

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { query, withTransaction } = require('../db/pool');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const AppError = require('../utils/AppError');
const env = require('../config/env');

// Hash refresh tokens before storing them (defense in depth — DB compromise
// shouldn't hand the attacker working tokens).
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// Strip sensitive fields before returning a user
function sanitizeUser(u) {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return rest;
}

async function register({ name, email, password, phone, role, dept }) {
  const password_hash = await bcrypt.hash(password, env.BCRYPT_ROUNDS);

  try {
    const { rows } = await query(
      `INSERT INTO users (name, email, password_hash, phone, role, dept)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, name, email, phone, role, dept, color, is_active, created_at`,
      [name, email, password_hash, phone, role, dept]
    );
    return rows[0];
  } catch (err) {
    if (err.code === '23505') throw AppError.conflict('Email already registered');
    throw err;
  }
}

async function login({ email, password, userAgent, ip }) {
  const { rows } = await query(
    'SELECT * FROM users WHERE email = $1 AND is_active = true',
    [email]
  );
  const user = rows[0];

  // Always compare a hash even if user not found — prevents timing attacks
  // that would otherwise leak whether an email exists.
  const dummyHash = '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv';
  const ok = await bcrypt.compare(password, user?.password_hash || dummyHash);

  if (!user || !ok) throw AppError.unauthorized('Invalid email or password');

  // Update last_login_at (fire and forget — if it fails, login still succeeds)
  query('UPDATE users SET last_login_at = now() WHERE id = $1', [user.id]).catch(() => {});

  return issueTokens(user, userAgent, ip);
}

async function issueTokens(user, userAgent, ip) {
  const payload = { sub: String(user.id), email: user.email, role: user.role };
  const accessToken  = signAccessToken(payload);
  const refreshToken = signRefreshToken({ sub: String(user.id), tokenId: crypto.randomUUID() });

  // Decode to get exact expiry from the token itself
  const { exp } = require('jsonwebtoken').decode(refreshToken);

  await query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, ip)
     VALUES ($1, $2, to_timestamp($3), $4, $5)`,
    [user.id, hashToken(refreshToken), exp, userAgent || null, ip || null]
  );

  return { accessToken, refreshToken, user: sanitizeUser(user) };
}

async function refresh(refreshToken, userAgent, ip) {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw AppError.unauthorized('Invalid or expired refresh token');
  }

  // Token rotation: invalidate old, issue new. If someone replays the old token,
  // the next refresh will fail (because we revoked it) — clear sign of theft.
  return withTransaction(async (client) => {
    const tokenHash = hashToken(refreshToken);

    const { rows: tokenRows } = await client.query(
      `SELECT rt.*, u.* FROM refresh_tokens rt
       JOIN users u ON u.id = rt.user_id
       WHERE rt.token_hash = $1
         AND rt.revoked_at IS NULL
         AND rt.expires_at > now()
         AND u.is_active = true`,
      [tokenHash]
    );
    if (tokenRows.length === 0) throw AppError.unauthorized('Refresh token revoked or invalid');

    // Revoke old
    await client.query(
      'UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1',
      [tokenHash]
    );

    // Issue new — use the user fields from the joined query
    const user = tokenRows[0];
    const newAccess  = signAccessToken({ sub: String(user.user_id), email: user.email, role: user.role });
    const newRefresh = signRefreshToken({ sub: String(user.user_id), tokenId: crypto.randomUUID() });
    const { exp } = require('jsonwebtoken').decode(newRefresh);

    await client.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, ip)
       VALUES ($1, $2, to_timestamp($3), $4, $5)`,
      [user.user_id, hashToken(newRefresh), exp, userAgent || null, ip || null]
    );

    return {
      accessToken: newAccess,
      refreshToken: newRefresh,
      user: { id: user.user_id, name: user.name, email: user.email, role: user.role },
    };
  });
}

async function logout(refreshToken) {
  if (!refreshToken) return;
  await query(
    'UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL',
    [hashToken(refreshToken)]
  );
}

async function logoutAll(userId) {
  await query(
    'UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL',
    [userId]
  );
}

async function changePassword(userId, { currentPassword, newPassword }) {
  const { rows } = await query('SELECT password_hash FROM users WHERE id = $1', [userId]);
  if (rows.length === 0) throw AppError.notFound('User not found');

  const ok = await bcrypt.compare(currentPassword, rows[0].password_hash);
  if (!ok) throw AppError.unauthorized('Current password is incorrect');

  const newHash = await bcrypt.hash(newPassword, env.BCRYPT_ROUNDS);
  await withTransaction(async (client) => {
    await client.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, userId]);
    // Revoke all existing sessions — force re-login everywhere
    await client.query(
      'UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL',
      [userId]
    );
  });
}

async function getMe(userId) {
  const { rows } = await query(
    `SELECT id, name, email, phone, role, dept, color, is_active, last_login_at, created_at
     FROM users WHERE id = $1`,
    [userId]
  );
  if (rows.length === 0) throw AppError.notFound('User not found');
  return rows[0];
}

module.exports = { register, login, refresh, logout, logoutAll, changePassword, getMe, sanitizeUser };
