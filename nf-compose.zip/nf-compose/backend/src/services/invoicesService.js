// src/services/invoicesService.js
const { query, withTransaction } = require('../db/pool');
const AppError = require('../utils/AppError');
const { parseSort } = require('../utils/sqlBuilders');

const SORTABLE = ['invoice_date', 'due_date', 'total', 'created_at'];

// Round money to 2 decimals using string-based rounding to avoid float drift.
// Postgres NUMERIC does the right thing on its end; this is for the JS calc.
function round2(n) { return Math.round(Number(n) * 100) / 100; }

function computeTotals(items, gst_rate) {
  const subtotal   = round2(items.reduce((s, it) => s + Number(it.amount), 0));
  const gst_amount = round2((subtotal * Number(gst_rate)) / 100);
  const total      = round2(subtotal + gst_amount);
  return { subtotal, gst_amount, total };
}

async function list(q) {
  const { page, limit, sort } = q;
  const offset = (page - 1) * limit;

  const filters = [];
  const params = [];
  if (q.q)          { params.push(`%${q.q}%`);    filters.push(`(i.id ILIKE $${params.length} OR c.name ILIKE $${params.length} OR c.company ILIKE $${params.length})`); }
  if (q.client_id)  { params.push(q.client_id);   filters.push(`i.client_id = $${params.length}`); }
  if (q.status)     { params.push(q.status);      filters.push(`i.status = $${params.length}`); }

  const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  const orderBy = parseSort(sort, SORTABLE, 'invoice_date DESC').replace(/^"?(\w+)"?/, 'i."$1"');

  params.push(limit, offset);
  const limitParam  = params.length - 1;
  const offsetParam = params.length;

  const itemsSql = `
    SELECT i.*,
           c.name AS client_name, c.company AS client_company
    FROM v_invoices i
    JOIN clients c ON c.id = i.client_id
    ${whereSql}
    ORDER BY ${orderBy}
    LIMIT $${limitParam} OFFSET $${offsetParam}
  `;
  const countSql = `SELECT count(*)::int AS total FROM v_invoices i JOIN clients c ON c.id = i.client_id ${whereSql}`;
  const countParams = params.slice(0, params.length - 2);

  const [rows, count] = await Promise.all([
    query(itemsSql, params),
    query(countSql, countParams),
  ]);

  return { items: rows.rows, page, limit, total: count.rows[0].total };
}

async function getById(id) {
  const inv = await query(
    `SELECT i.*, c.name AS client_name, c.company AS client_company
     FROM v_invoices i
     JOIN clients c ON c.id = i.client_id
     WHERE i.id = $1`,
    [id]
  );
  if (inv.rows.length === 0) throw AppError.notFound('Invoice not found');

  const items = await query(
    `SELECT id, project_id, description, amount, position
     FROM invoice_items WHERE invoice_id = $1 ORDER BY position, id`,
    [id]
  );

  return { ...inv.rows[0], items: items.rows };
}

// Generate the next ID atomically using the sequence
async function nextInvoiceId(client) {
  const { rows } = await client.query("SELECT 'INV-' || nextval('invoice_number_seq') AS id");
  return rows[0].id;
}

async function create(input) {
  const { subtotal, gst_amount, total } = computeTotals(input.items, input.gst_rate);

  return withTransaction(async (client) => {
    // Verify client exists and isn't deleted (FK check would fire too, but a
    // clean 404 is friendlier than "FOREIGN_KEY_VIOLATION")
    const c = await client.query(
      'SELECT 1 FROM clients WHERE id = $1 AND deleted_at IS NULL',
      [input.client_id]
    );
    if (c.rowCount === 0) throw AppError.badRequest('Client not found');

    const id = await nextInvoiceId(client);

    await client.query(
      `INSERT INTO invoices (id, client_id, invoice_date, due_date, subtotal, gst_rate, gst_amount, total, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [id, input.client_id, input.invoice_date, input.due_date, subtotal, input.gst_rate, gst_amount, total, input.notes ?? null]
    );

    for (let i = 0; i < input.items.length; i++) {
      const it = input.items[i];
      await client.query(
        `INSERT INTO invoice_items (invoice_id, project_id, description, amount, position)
         VALUES ($1, $2, $3, $4, $5)`,
        [id, it.project_id ?? null, it.description, it.amount, i]
      );
    }

    return id;
  }).then(getById);
}

async function update(id, input) {
  return withTransaction(async (client) => {
    const existing = await client.query('SELECT * FROM invoices WHERE id = $1', [id]);
    if (existing.rows.length === 0) throw AppError.notFound('Invoice not found');

    const cur = existing.rows[0];
    const items_changed = !!input.items;
    const gst_rate = input.gst_rate ?? Number(cur.gst_rate);

    let subtotal = Number(cur.subtotal);
    let gst_amount = Number(cur.gst_amount);
    let total = Number(cur.total);

    if (items_changed) {
      ({ subtotal, gst_amount, total } = computeTotals(input.items, gst_rate));

      // Sanity check: can't reduce total below what's already paid
      if (total < Number(cur.paid_amount)) {
        throw AppError.badRequest(`New total (${total}) is less than already-paid amount (${cur.paid_amount})`);
      }

      await client.query('DELETE FROM invoice_items WHERE invoice_id = $1', [id]);
      for (let i = 0; i < input.items.length; i++) {
        const it = input.items[i];
        await client.query(
          `INSERT INTO invoice_items (invoice_id, project_id, description, amount, position)
           VALUES ($1, $2, $3, $4, $5)`,
          [id, it.project_id ?? null, it.description, it.amount, i]
        );
      }
    } else if (input.gst_rate !== undefined) {
      gst_amount = round2((subtotal * gst_rate) / 100);
      total = round2(subtotal + gst_amount);
      if (total < Number(cur.paid_amount)) {
        throw AppError.badRequest('New total is less than already-paid amount');
      }
    }

    await client.query(
      `UPDATE invoices SET
         invoice_date = COALESCE($1, invoice_date),
         due_date     = COALESCE($2, due_date),
         gst_rate     = $3,
         subtotal     = $4,
         gst_amount   = $5,
         total        = $6,
         notes        = COALESCE($7, notes)
       WHERE id = $8`,
      [
        input.invoice_date ?? null,
        input.due_date ?? null,
        gst_rate, subtotal, gst_amount, total,
        input.notes ?? null,
        id,
      ]
    );
  }).then(() => getById(id));
}

async function recordPayment(id, amount) {
  return withTransaction(async (client) => {
    // SELECT FOR UPDATE locks the row so concurrent payments can't overpay
    const { rows } = await client.query(
      'SELECT total, paid_amount FROM invoices WHERE id = $1 FOR UPDATE',
      [id]
    );
    if (rows.length === 0) throw AppError.notFound('Invoice not found');

    const newPaid = round2(Number(rows[0].paid_amount) + Number(amount));
    if (newPaid > Number(rows[0].total)) {
      throw AppError.badRequest(`Payment would exceed invoice total (max remaining: ${round2(rows[0].total - rows[0].paid_amount)})`);
    }

    await client.query('UPDATE invoices SET paid_amount = $1 WHERE id = $2', [newPaid, id]);
  }).then(() => getById(id));
}

async function remove(id) {
  // Hard delete invoices is unusual in accounting systems. Forbid if any
  // payment has been recorded; otherwise allow.
  const { rows } = await query('SELECT paid_amount FROM invoices WHERE id = $1', [id]);
  if (rows.length === 0) throw AppError.notFound('Invoice not found');
  if (Number(rows[0].paid_amount) > 0) {
    throw AppError.conflict('Cannot delete an invoice with recorded payments');
  }
  await query('DELETE FROM invoices WHERE id = $1', [id]);
}

module.exports = { list, getById, create, update, recordPayment, remove };
