// src/server.js
// Boots the HTTP server and handles graceful shutdown.
// On SIGTERM/SIGINT: stop accepting new connections, drain in-flight requests, close DB pool, exit.

const env = require('./config/env');
const logger = require('./config/logger');
const app = require('./app');
const { close: closeDb, query } = require('./db/pool');

let server;

async function start() {
  // Verify DB is reachable before announcing we're ready
  try {
    await query('SELECT 1');
    logger.info('Database connection OK');
  } catch (err) {
    logger.fatal({ err }, 'Could not connect to database — exiting');
    process.exit(1);
  }

  server = app.listen(env.PORT, () => {
    logger.info(`🚀 Nova Fusion API listening on http://localhost:${env.PORT} (${env.NODE_ENV})`);
  });

  server.keepAliveTimeout = 65_000; // > typical LB idle timeout
  server.headersTimeout = 66_000;
}

async function shutdown(signal) {
  logger.info({ signal }, 'Shutdown signal received');

  // Force-exit if graceful shutdown takes too long
  const forceTimer = setTimeout(() => {
    logger.error('Forced shutdown after 10s');
    process.exit(1);
  }, 10_000);
  forceTimer.unref();

  try {
    if (server) {
      await new Promise((resolve, reject) => server.close((err) => (err ? reject(err) : resolve())));
      logger.info('HTTP server closed');
    }
    await closeDb();
    logger.info('Database pool closed');
    process.exit(0);
  } catch (err) {
    logger.error({ err }, 'Error during shutdown');
    process.exit(1);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (reason) => {
  logger.error({ err: reason }, 'Unhandled promise rejection');
});

process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'Uncaught exception — shutting down');
  shutdown('uncaughtException');
});

start().catch((err) => {
  logger.fatal({ err }, 'Startup failed');
  process.exit(1);
});
