// src/middleware/validate.js
// Builds a middleware that validates req.body / req.query / req.params against a Zod schema.
// On success, replaces the value with the parsed (and coerced) version so downstream code
// is dealing with clean, typed data.
//
// Usage:
//   router.post('/clients', validate({ body: clientCreateSchema }), controller.create);

module.exports = (schemas) => (req, res, next) => {
  try {
    if (schemas.body)   req.body   = schemas.body.parse(req.body);
    if (schemas.query)  req.query  = schemas.query.parse(req.query);
    if (schemas.params) req.params = schemas.params.parse(req.params);
    next();
  } catch (err) {
    next(err); // Zod errors are handled in errorHandler
  }
};
