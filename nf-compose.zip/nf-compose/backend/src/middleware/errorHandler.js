// src/middleware/errorHandler.js
// The ONE place errors become HTTP responses. Anything thrown anywhere ends up here.

const { ZodError } = require('zod');
const AppError = require('../utils/AppError');
const logger = require('../config/logger');
const env = require('../config/env');

// 404 for unmatched routes — mount this AFTER all other routes.
function notFoundHandler(req, res, next) {
  next(AppError.notFound(`Route not found: ${req.method} ${req.originalUrl}`));
}

// Final error handler. Express recognizes it by the 4-arg signature.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Zod validation errors
  if (err instanceof ZodError) {
    return res.status(422).json({
      error: {
        code: 'VALIDATION_ERROR',
        message: 'Validation failed',
        details: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
      },
    });
  }

  // PostgreSQL errors — translate the common ones into useful HTTP responses
  if (err.code && typeof err.code === 'string' && /^[0-9A-Z]{5}$/.test(err.code)) {
    if (err.code === '23505') {
      return res.status(409).json({
        error: { code: 'DUPLICATE', message: 'Resource already exists', details: err.detail },
      });
    }
    if (err.code === '23503') {
      return res.status(409).json({
        error: { code: 'FOREIGN_KEY_VIOLATION', message: 'Referenced resource does not exist', details: err.detail },
      });
    }
    if (err.code === '23502') {
      return res.status(400).json({
        error: { code: 'NOT_NULL_VIOLATION', message: 'Required field missing', details: err.column },
      });
    }
  }

  // Our own AppErrors
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: { code: err.code, message: err.message, ...(err.details && { details: err.details }) },
    });
  }

  // Anything else = unexpected. Log fully, return generic message.
  logger.error({ err, reqId: req.id, url: req.originalUrl }, 'Unhandled error');
  res.status(500).json({
    error: {
      code: 'INTERNAL_ERROR',
      message: env.isProd ? 'Internal server error' : err.message,
      ...(env.isDev && { stack: err.stack }),
    },
  });
}

module.exports = { notFoundHandler, errorHandler };
