// src/middleware/scope.js
// Data-level RBAC. Route gates (requireRole) answer "can you call this endpoint";
// this module answers "which rows can you see".
//
// Rules:
//   Admin (founder) / Manager  → all projects, all finance
//   Editor / Staff (team)      → only projects where they are the project
//                                assignee, a project member, or assigned to
//                                any workflow step or checklist item.

const { query } = require('../db/pool');
const AppError = require('../utils/AppError');

function isElevated(user) {
  return user && (user.role === 'Admin' || user.role === 'Manager');
}

// Returns an SQL fragment (starting with " AND ...") that restricts a query on
// projects aliased `alias` to what `user` may see. Pushes the user id into
// `params`. Elevated roles get an empty fragment (no restriction).
function projectScopeSql(user, params, alias = 'p') {
  if (isElevated(user)) return '';
  params.push(Number(user.id));
  const n = params.length;
  return ` AND (
    ${alias}.assignee_id = $${n}
    OR EXISTS (SELECT 1 FROM project_members pm WHERE pm.project_id = ${alias}.id AND pm.user_id = $${n})
    OR EXISTS (SELECT 1 FROM workflow_steps ws WHERE ws.project_id = ${alias}.id AND ws.assignee_id = $${n})
    OR EXISTS (SELECT 1 FROM checklist_items ci JOIN workflow_steps ws2 ON ws2.id = ci.step_id
               WHERE ws2.project_id = ${alias}.id AND ci.assignee_id = $${n})
  )`;
}

// Throws 403 if `user` cannot see project `projectId`. Returns the project row.
async function assertProjectAccess(user, projectId) {
  const params = [projectId];
  const scope = projectScopeSql(user, params);
  const { rows } = await query(
    `SELECT p.* FROM projects p WHERE p.id = $1 AND p.deleted_at IS NULL ${scope}`,
    params
  );
  if (!rows[0]) throw AppError.forbidden('You do not have access to this project');
  return rows[0];
}

// Strip money fields for non-elevated users. Members run projects;
// only Manager/Admin see quotes, collections and billing.
function redactProject(user, project) {
  if (isElevated(user) || !project) return project;
  const { amount, paid_amount, payment, ...rest } = project;
  return rest;
}

module.exports = { isElevated, projectScopeSql, assertProjectAccess, redactProject };
