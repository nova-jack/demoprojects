# Nova Fusion Backend

Production-grade REST API for the Nova Fusion RCM Portal.

## Stack

- **Node.js 20+** with Express
- **PostgreSQL 14+** (raw SQL via `pg`, no ORM)
- **JWT** auth with refresh-token rotation + server-side revocation, bcrypt hashing
- **Zod** for request validation
- **Pino** for structured logging with secret redaction
- **Helmet + CORS + rate limiting** for security

## Setup

### 1. Install Postgres on your server
```bash
apt install postgresql postgresql-contrib
sudo -u postgres psql -c "CREATE USER novafusion WITH PASSWORD 'a-strong-password';"
sudo -u postgres psql -c "CREATE DATABASE novafusion OWNER novafusion;"
```

### 2. Install backend
```bash
npm install
cp .env.example .env
# In .env, set DATABASE_URL to: postgresql://novafusion:your-password@localhost:5432/novafusion
# Then generate JWT secrets:
echo "JWT_ACCESS_SECRET=$(openssl rand -hex 64)" >> .env
echo "JWT_REFRESH_SECRET=$(openssl rand -hex 64)" >> .env
```

### 3. Migrate
```bash
npm run migrate
```

### 4. Create the first admin
```bash
ADMIN_NAME="Owner" ADMIN_EMAIL="you@nova.in" ADMIN_PASSWORD="strong-pass-here" npm run create-admin
```

### 5. Run
```bash
npm run dev      # auto-restart on file change
npm start        # production
```

## API Reference

All routes prefixed with `/api`. All responses are JSON.

### Auth
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/login` | — | Returns `{accessToken, refreshToken, user}` |
| POST | `/auth/refresh` | — | Rotates refresh token, returns new pair |
| POST | `/auth/logout` | ✓ | Revokes the supplied refresh token |
| POST | `/auth/logout-all` | ✓ | Revokes ALL sessions for current user |
| GET | `/auth/me` | ✓ | Current user profile |
| POST | `/auth/change-password` | ✓ | Updates password + revokes all sessions |
| POST | `/auth/register` | Admin | Create a new team member |

### Resources
| Resource | Endpoints | Notes |
|---|---|---|
| `/clients` | GET / GET:id / POST / PATCH:id / DELETE:id | Soft delete; list returns billing stats per client |
| `/projects` | GET / GET:id / POST / PATCH:id / DELETE:id | Filter by client/assignee/stage/priority/payment |
| `/invoices` | GET / GET:id / POST / PATCH:id / DELETE:id | Items via nested `items[]`, computed totals |
| `/invoices/:id/payments` | POST | Record a payment, status auto-updates |
| `/tasks` | GET / POST / PATCH:id / DELETE:id | Filter by project/assignee/done |
| `/expenses` | GET / POST / PATCH:id / DELETE:id | Filter by category and date range |
| `/users` | GET / GET:id / PATCH:id | Admin manages team members |
| `/dashboard` | GET | Aggregate counts, revenue, outstanding, deadlines |
| `/health/live` | GET | Liveness probe |
| `/health/ready` | GET | Liveness + DB connectivity |

### Authorization
| Role | Can do |
|---|---|
| Admin | Everything (incl. delete, register users, edit team) |
| Manager | Create/edit clients, projects, invoices, expenses, record payments |
| Editor | Edit projects (e.g. update stage), manage own tasks |
| Staff | Read everything, manage own tasks |

### Response shape

**List:**
```json
{ "items": [...], "page": 1, "limit": 20, "total": 42 }
```

**Single:**
```json
{ "id": "1", "name": "...", ... }
```

**Error:**
```json
{ "error": { "code": "VALIDATION_ERROR", "message": "...", "details": [...] } }
```

Error codes: `BAD_REQUEST`, `UNAUTHORIZED`, `FORBIDDEN`, `NOT_FOUND`,
`CONFLICT`, `VALIDATION_ERROR`, `RATE_LIMITED`, `DUPLICATE`, `INTERNAL_ERROR`.

## Architecture notes

**Why no ORM?** With raw SQL + the `pg` driver, queries stay transparent and
fast. Migrations + Zod validation + a small `buildUpdate` helper give the
convenience without ORM overhead, lock-in, or N+1 footguns.

**Money is `NUMERIC(14,2)`** everywhere — never floats. JS-side calcs use
`Math.round(x * 100) / 100`. Postgres handles arithmetic exactly.

**Payment status is computed, not stored.** `v_invoices` and `v_projects`
views derive `Paid/Partial/Unpaid` from `paid_amount` vs `total`. One source
of truth, no drift.

**Soft delete via `deleted_at`** for clients/projects so historical invoices
keep their references. Partial indexes keep queries fast.

**Refresh-token rotation** with server-side revocation. Tokens stored as
SHA-256 hashes — DB compromise yields no working tokens. Replaying a used
token fails loudly (sign of theft).

**Transactions** wrap any multi-step write (invoice + items, password change
+ session revoke, payment recording with `SELECT FOR UPDATE`).

## Running behind Nginx

```nginx
location /api/ {
  proxy_pass http://localhost:3000;
  proxy_http_version 1.1;
  proxy_set_header Host $host;
  proxy_set_header X-Real-IP $remote_addr;
  proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  proxy_set_header X-Forwarded-Proto $scheme;
  proxy_read_timeout 65s;
}
```

The app sets `trust proxy: 1`, so `req.ip` and rate limiting work correctly behind one proxy hop.
